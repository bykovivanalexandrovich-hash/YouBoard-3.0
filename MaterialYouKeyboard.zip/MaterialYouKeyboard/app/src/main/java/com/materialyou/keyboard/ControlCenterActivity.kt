package com.materialyou.keyboard

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.DragEvent
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.pm.PackageInfoCompat
import androidx.core.os.LocaleListCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

class ControlCenterActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private var taps = 0
    private var lastTap = 0L
    private var toast: Toast? = null
    private var barCtl: BottomBar.Controller? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        barCtl?.feed(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_control)
        // status bar icons follow the theme: dark icons on a light bar, light icons on a dark bar
        androidx.core.view.WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
            (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) !=
                    android.content.res.Configuration.UI_MODE_NIGHT_YES
        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)

        findViewById<MaterialToolbar>(R.id.cc_toolbar).setNavigationOnClickListener { finish() }
        Groups.scan(this, prefs, "groups_open_cc")
        barCtl = BottomBar.attach(this, BottomBar.CONTROL)

        // language
        val group = findViewById<RadioGroup>(R.id.lang_group)
        group.removeAllViews()
        val curLang = prefs.getString(Loc.KEY, "system")
        fun addLang(code: String, label: String) {
            val rb = com.google.android.material.radiobutton.MaterialRadioButton(this).apply {
                id = View.generateViewId()
                text = label
                tag = code
                setPadding(dp(12), 0, 0, 0)
            }
            group.addView(rb, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
            if (code == curLang) group.check(rb.id)
        }
        addLang("system", getString(R.string.lang_system))
        for (d in Langs.all) addLang(d.code.lowercase(), d.title)
        group.setOnCheckedChangeListener { g, id ->
            val v = (g.findViewById<View>(id)?.tag as? String) ?: "system"
            if (v != prefs.getString(Loc.KEY, "system")) {
                prefs.edit().putString(Loc.KEY, v).apply()
                applyLanguage(v)
            }
        }

        // app theme (light / dark / system); the keyboard itself follows the system as before
        val tg = findViewById<RadioGroup>(R.id.theme_group)
        tg.removeAllViews()
        val curTheme = prefs.getString(App.THEME_KEY, "system")
        for ((code, res) in listOf("system" to R.string.at_system, "light" to R.string.at_light, "dark" to R.string.at_dark)) {
            val rb = com.google.android.material.radiobutton.MaterialRadioButton(this).apply {
                id = View.generateViewId()
                text = getString(res)
                tag = code
                setPadding(dp(12), 0, 0, 0)
            }
            tg.addView(rb, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
            if (code == curTheme) tg.check(rb.id)
        }
        tg.setOnCheckedChangeListener { g, id ->
            val v = (g.findViewById<View>(id)?.tag as? String) ?: "system"
            if (v != prefs.getString(App.THEME_KEY, "system")) {
                prefs.edit().putString(App.THEME_KEY, v).apply()
                App.applyTheme(v)
            }
        }

        // keyboard languages
        buildLangList()

        setupVoice()

        // reset
        findViewById<View>(R.id.btn_reset).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.reset_title)
                .setMessage(R.string.reset_msg)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.reset_ok) { _, _ -> resetAll() }
                .show()
        }

        // version + hidden settings (7 taps)
        val ver = findViewById<TextView>(R.id.version)
        val info = packageManager.getPackageInfo(packageName, 0)
        ver.text = getString(R.string.version_fmt, info.versionName ?: "", PackageInfoCompat.getLongVersionCode(info).toInt())
        ver.setOnClickListener { onVersionTap() }
    }

    private fun addSwitch(container: ViewGroup, title: String, summary: String, key: String, def: Boolean, onChange: ((Boolean) -> Unit)? = null) {
        val row = layoutInflater.inflate(R.layout.item_switch, container, false)
        row.findViewById<TextView>(R.id.row_title).text = title
        row.findViewById<TextView>(R.id.row_summary).text = summary
        val sw = row.findViewById<MaterialSwitch>(R.id.row_switch)
        row.isSaveFromParentEnabled = false
        row.isSaveEnabled = false
        sw.isSaveEnabled = false
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            onChange?.invoke(checked)
        }
        row.setOnClickListener { sw.toggle() }
        container.addView(row)
    }

    private fun updateMicButton() {
        findViewById<View>(R.id.btn_mic_perm)?.visibility =
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) View.GONE else View.VISIBLE
    }

    override fun onResume() {
        super.onResume()
        updateMicButton()
    }

    private fun setupVoice() {
        val box = findViewById<LinearLayout>(R.id.group_voice)
        val group = findViewById<RadioGroup>(R.id.voice_lang_group)
        val label = findViewById<View>(R.id.voice_lang_label)
        fun applyEnabled(on: Boolean) {
            val a = if (on) 1f else 0.4f
            label.alpha = a
            group.alpha = a
            for (i in 0 until group.childCount) group.getChildAt(i).isEnabled = on
        }
        addSwitch(box, getString(R.string.sw_voice), getString(R.string.sw_voice_s), "voice_enabled", true) {
            applyEnabled(it)
        }
        applyEnabled(prefs.getBoolean("voice_enabled", true))
        group.check(
            when (prefs.getString("voice_lang", "any")) {
                "ru" -> R.id.voice_ru
                "uk" -> R.id.voice_uk
                "en" -> R.id.voice_en
                else -> R.id.voice_any
            }
        )
        group.setOnCheckedChangeListener { _, id ->
            val v = when (id) {
                R.id.voice_ru -> "ru"
                R.id.voice_uk -> "uk"
                R.id.voice_en -> "en"
                else -> "any"
            }
            prefs.edit().putString("voice_lang", v).apply()
        }
        updateMicButton()
        findViewById<View>(R.id.btn_mic_perm).setOnClickListener {
            startActivity(Intent(this, VoicePermissionActivity::class.java))
        }
    }

    // ------------------------------------------------------------ keyboard languages (25)

    private val downloading = mutableSetOf<String>()

    private fun buildLangList() {
        val list = findViewById<LinearLayout>(R.id.kb_list)
        list.removeAllViews()
        val ru = Loc.isRu(prefs)
        val muted = col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt())
        val onSurface = col(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        for (d in Langs.all) {
            val installed = Langs.installed(this, d)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(20), dp(8), dp(16), dp(8))
                minimumHeight = dp(60)
            }
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(TextView(this).apply {
                text = d.title
                textSize = 16f
                setTextColor(onSurface)
            })
            texts.addView(TextView(this).apply {
                val name = if (ru) d.ru else d.en
                val state = when {
                    d.builtin -> getString(R.string.lang_builtin)
                    installed -> getString(R.string.lang_ready)
                    else -> getString(R.string.lang_not_downloaded)
                }
                text = "$name · $state"
                textSize = 12f
                setTextColor(muted)
            })
            row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (installed) {
                val sw = MaterialSwitch(this).apply {
                    isSaveEnabled = false
                    isChecked = d.code in Langs.enabledCodes(prefs) || (prefs.getString("langs_on", null) == null && Langs.enabled(this@ControlCenterActivity, prefs).contains(d))
                    setOnCheckedChangeListener { _, on ->
                        val cur = Langs.enabled(this@ControlCenterActivity, prefs).map { it.code }.toMutableSet()
                        if (on) cur.add(d.code) else cur.remove(d.code)
                        if (cur.isEmpty()) {
                            cur.add("EN")
                            Toast.makeText(this@ControlCenterActivity, R.string.lang_need_one, Toast.LENGTH_SHORT).show()
                        }
                        Langs.setEnabled(prefs, cur)
                        buildLangList()
                    }
                }
                row.addView(sw)
                if (!d.builtin) row.setOnLongClickListener {
                    MaterialAlertDialogBuilder(this)
                        .setTitle(getString(R.string.lang_delete_title, d.title))
                        .setMessage(R.string.lang_delete_msg)
                        .setNegativeButton(R.string.cancel, null)
                        .setPositiveButton(R.string.lang_delete_ok) { _, _ ->
                            Langs.file(this, d).delete()
                            val cur = Langs.enabled(this, prefs).map { it.code }.toMutableSet()
                            cur.remove(d.code)
                            if (cur.isEmpty()) cur.add("EN")
                            Langs.setEnabled(prefs, cur)
                            buildLangList()
                        }
                        .show()
                    true
                }
            } else {
                val busy = d.code in downloading
                if (busy) {
                    row.addView(WavyProgressView(this), LinearLayout.LayoutParams(dp(40), dp(40)))
                    list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    continue
                }
                val btn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                    text = getString(if (busy) R.string.lang_downloading else R.string.lang_download)
                    isEnabled = !busy
                    setOnClickListener {
                        downloading.add(d.code)
                        buildLangList()
                        LangDownloader.download(this@ControlCenterActivity, d) { ok ->
                            downloading.remove(d.code)
                            if (ok) {
                                val cur = Langs.enabled(this@ControlCenterActivity, prefs).map { it.code }.toMutableSet()
                                cur.add(d.code)
                                Langs.setEnabled(prefs, cur)
                            } else {
                                Toast.makeText(this@ControlCenterActivity, R.string.lang_dl_fail, Toast.LENGTH_LONG).show()
                            }
                            if (!isFinishing && !isDestroyed) buildLangList()
                        }
                    }
                }
                row.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun applyLanguage(v: String) {
        val tags = if (v == "system") LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(v)
        AppCompatDelegate.setApplicationLocales(tags)
    }

    private fun resetAll() {
        val e = prefs.edit()
        for (k in listOf(
            "vibrate", "sound", "number_row", "autocap", "suggestions", "autocorrect", "clip_history",
            "clip_chip", "clip_mask", "plus", "key_height", "big_letters", "voice_enabled", "voice_lang", "lang_globe", "lang_swipe", LangSwitch.KEY, "lang_switch_all", "hard_sign_alt", Themes.KEY, "square_mode", "sym_in_123", "touch_guard", "bigrams", "space_joystick", "swipe_typing", "groups_collapse", "my_emoji", "bg_photo_on", "bg_sel", "one_hand", "one_hand_side", "shortcuts_on", "shortcuts", "groups_open", "groups_open_themes", "groups_open_log", "groups_open_cc", "key_round", "debug_mode", "dbg_log", "win95", "hide_emoji_btn", "profanity_filter", "grad_fx", "plus_shapes",
            Layouts.CUSTOM, "layout_RU", "layout_UK", "layout_EN", "kb_langs", "langs_on", Loc.KEY, App.THEME_KEY, "fx_x", "fx_y", "fx_size"
        )) e.remove(k)
        prefs.all.keys.filter { it.startsWith("ke_") }.forEach { e.remove(it) }
        e.apply()
        App.applyTheme("system")
        applyLanguage("system")
        Toast.makeText(this, R.string.reset_done, Toast.LENGTH_SHORT).show()
        recreate()
    }

    private fun onVersionTap() {
        val now = System.currentTimeMillis()
        if (now - lastTap > 2000) taps = 0
        lastTap = now
        taps++
        toast?.cancel()
        if (taps >= 7) {
            taps = 0
            showAdvanced()
        } else if (taps >= 3) {
            toast = Toast.makeText(this, getString(R.string.dev_left, 7 - taps), Toast.LENGTH_SHORT).also { it.show() }
        }
    }

    // ------------------------------------------------------------ hidden: custom key layout

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun col(attr: Int, fb: Int): Int = MaterialColors.getColor(this, attr, fb)

    private fun showAdvanced() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(4))
        }
        val swSquare = MaterialSwitch(this).apply {
            text = getString(R.string.sw_square)
            textSize = 16f
            isChecked = prefs.getBoolean("square_mode", false)
            setOnCheckedChangeListener { _, on ->
                val e = prefs.edit().putBoolean("square_mode", on)
                if (on) e.putBoolean("plus", false) // square keys and Material You + exclude each other
                e.apply()
            }
        }
        content.addView(swSquare, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val squareHint = TextView(this).apply {
            text = getString(R.string.square_hint)
            textSize = 12f
            setTextColor(col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt()))
            setPadding(0, 0, 0, dp(14))
        }
        content.addView(squareHint)

        val swAll = MaterialSwitch(this).apply {
            text = getString(R.string.sw_langall)
            textSize = 16f
            val joyOn = prefs.getBoolean("space_joystick", false)
            isChecked = prefs.getBoolean("lang_switch_all", false) && !joyOn
            isEnabled = !joyOn
            alpha = if (joyOn) 0.4f else 1f
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("lang_switch_all", on).apply() }
        }
        content.addView(swAll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(TextView(this).apply {
            text = getString(R.string.langall_hint)
            textSize = 12f
            setTextColor(col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt()))
            setPadding(0, 0, 0, dp(14))
        })

        val swGroups = MaterialSwitch(this).apply {
            text = getString(R.string.sw_groups)
            textSize = 16f
            isChecked = prefs.getBoolean("groups_collapse", true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("groups_collapse", on).apply() }
        }
        content.addView(swGroups, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(TextView(this).apply {
            text = getString(R.string.sw_groups_s)
            textSize = 12f
            setTextColor(col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt()))
            setPadding(0, 0, 0, dp(14))
        })

        val swWin = MaterialSwitch(this).apply {
            text = getString(R.string.sw_win95)
            textSize = 16f
            isChecked = prefs.getBoolean("win95", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("win95", on).apply() }
        }
        content.addView(swWin, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(TextView(this).apply {
            text = getString(R.string.sw_win95_s)
            textSize = 12f
            setTextColor(col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt()))
            setPadding(0, 0, 0, dp(14))
        })

        val swDbg = MaterialSwitch(this).apply {
            text = getString(R.string.sw_debug)
            textSize = 16f
            isChecked = prefs.getBoolean("debug_mode", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("debug_mode", on).apply() }
        }
        content.addView(swDbg, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(TextView(this).apply {
            text = getString(R.string.debug_hint)
            textSize = 12f
            setTextColor(col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt()))
            setPadding(0, 0, 0, dp(14))
        })

        val logView = TextView(this).apply {
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 10f
            setTextIsSelectable(true)
            setTextColor(col(com.google.android.material.R.attr.colorOnSurface, 0xFFDDDDDD.toInt()))
            setPadding(0, 0, 0, dp(8))
        }
        val logBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (swDbg.isChecked) View.VISIBLE else View.GONE
            addView(TextView(context).apply {
                text = getString(R.string.dbg_log_title)
                textSize = 12f
                setTextColor(col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt()))
            })
            addView(logView)
            addView(MaterialButton(context, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = getString(R.string.dbg_log_clear)
                setOnClickListener {
                    prefs.edit().remove("dbg_log").apply()
                    logView.text = ""
                }
            })
        }
        fun refreshLog() {
            logView.text = (prefs.getString("dbg_log", "") ?: "").split('\n').takeLast(60).reversed().joinToString("\n")
        }
        refreshLog()
        swDbg.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("debug_mode", on).apply()
            logBox.visibility = if (on) View.VISIBLE else View.GONE
            refreshLog()
        }
        content.addView(logBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val sw = MaterialSwitch(this).apply {
            text = getString(R.string.custom_layout)
            textSize = 16f
            isChecked = Layouts.enabled(prefs)
        }
        content.addView(sw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val editor = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (sw.isChecked) View.VISIBLE else View.GONE
        }
        content.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val tabs = MaterialButtonToggleGroup(this).apply {
            isSingleSelection = true
            isSelectionRequired = true
        }
        val bRu = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "RU"
            id = View.generateViewId()
        }
        val bUk = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "UK"
            id = View.generateViewId()
        }
        val bEn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "EN"
            id = View.generateViewId()
        }
        tabs.addView(bRu)
        tabs.addView(bUk)
        tabs.addView(bEn)
        val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.topMargin = dp(12)
        tlp.gravity = Gravity.CENTER_HORIZONTAL
        editor.addView(tabs, tlp)

        val board = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp.topMargin = dp(12)
        editor.addView(board, blp)

        val hint = TextView(this).apply {
            text = getString(R.string.layout_hint)
            textSize = 12f
            setTextColor(col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt()))
        }
        val hlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hlp.topMargin = dp(10)
        editor.addView(hint, hlp)

        val reset = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = getString(R.string.layout_reset)
        }
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.topMargin = dp(8)
        editor.addView(reset, rlp)

        var code = "RU"
        fun current(): List<String> = Layouts.saved(prefs, code) ?: Layouts.defaults(code)
        fun render() = renderBoard(board, code, current())
        tabs.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                code = when (id) {
                    bRu.id -> "RU"
                    bUk.id -> "UK"
                    else -> "EN"
                }
                render()
            }
        }
        reset.setOnClickListener {
            Layouts.save(prefs, code, Layouts.defaults(code))
            render()
        }
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean(Layouts.CUSTOM, on).apply()
            if (on) {
                for (c in listOf("RU", "UK", "EN")) if (Layouts.saved(prefs, c) == null) Layouts.save(prefs, c, Layouts.defaults(c))
                render()
            }
            editor.visibility = if (on) View.VISIBLE else View.GONE
        }
        tabs.check(bRu.id)

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.adv_title)
            .setView(content)
            .setPositiveButton(R.string.close, null)
            .show()
    }

    private fun keyBg(selected: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(10).toFloat()
        setColor(
            if (selected) col(com.google.android.material.R.attr.colorPrimaryContainer, 0xFFD0BCFF.toInt())
            else col(com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E.toInt())
        )
    }

    private fun renderBoard(board: LinearLayout, code: String, rows: List<String>) {
        board.removeAllViews()
        val onSurface = col(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val grid = ArrayList<List<TextView>>()
        var selected: TextView? = null

        fun persist() {
            Layouts.save(prefs, code, grid.map { r -> r.joinToString("") { it.text.toString().lowercase() } })
        }

        fun swap(a: TextView, b: TextView) {
            val t = a.text
            a.text = b.text
            b.text = t
            persist()
        }

        for (row in rows) {
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_HORIZONTAL
                weightSum = rows[0].length.toFloat()
            }
            val cells = ArrayList<TextView>()
            for (ch in row) {
                val tv = TextView(this).apply {
                    text = ch.toString().uppercase()
                    gravity = Gravity.CENTER
                    textSize = 16f
                    setTextColor(onSurface)
                    background = keyBg(false)
                }
                var downX = 0f
                var downY = 0f
                var dragging = false
                tv.setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = e.x
                            downY = e.y
                            dragging = false
                        }
                        MotionEvent.ACTION_MOVE -> if (!dragging &&
                            (Math.abs(e.x - downX) > slop || Math.abs(e.y - downY) > slop)
                        ) {
                            dragging = true
                            v.parent?.requestDisallowInterceptTouchEvent(true)
                            val data = ClipData.newPlainText("key", (v as TextView).text)
                            v.startDragAndDrop(data, View.DragShadowBuilder(v), v, 0)
                            return@setOnTouchListener true
                        }
                    }
                    false
                }
                tv.setOnClickListener {
                    val s = selected
                    if (s == null) {
                        selected = tv
                        tv.background = keyBg(true)
                    } else {
                        s.background = keyBg(false)
                        selected = null
                        if (s !== tv) swap(s, tv)
                    }
                }
                tv.setOnDragListener { v, ev ->
                    when (ev.action) {
                        DragEvent.ACTION_DRAG_STARTED -> {
                            if (ev.localState === v) v.alpha = 0.35f
                            true
                        }
                        DragEvent.ACTION_DRAG_ENTERED -> {
                            if (ev.localState !== v) v.background = keyBg(true)
                            true
                        }
                        DragEvent.ACTION_DRAG_EXITED -> {
                            v.background = keyBg(false)
                            true
                        }
                        DragEvent.ACTION_DROP -> {
                            val src = ev.localState as? TextView
                            if (src != null && src !== v) swap(src, v as TextView)
                            true
                        }
                        DragEvent.ACTION_DRAG_ENDED -> {
                            v.alpha = 1f
                            v.background = keyBg(false)
                            true
                        }
                        else -> true
                    }
                }
                val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
                lp.setMargins(dp(2), dp(2), dp(2), dp(2))
                line.addView(tv, lp)
                cells.add(tv)
            }
            grid.add(cells)
            board.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }
}
