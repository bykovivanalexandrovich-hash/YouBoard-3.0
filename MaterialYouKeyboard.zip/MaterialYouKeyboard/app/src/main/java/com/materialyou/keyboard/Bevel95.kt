package com.materialyou.keyboard

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable

/** Windows 95 style key: flat grey face with a raised (or, when [sunken], pressed-in) two-line bevel. */
class Bevel95(private val d: Float) : GradientDrawable() {
    var sunken = false
        set(v) {
            if (field != v) {
                field = v
                invalidateSelf()
            }
        }
    private val paint = Paint().apply { style = Paint.Style.FILL }

    override fun draw(canvas: Canvas) {
        super.draw(canvas)
        val r = bounds
        val t = maxOf(1f, d * 1.2f)
        val l = r.left.toFloat()
        val tp = r.top.toFloat()
        val rt = r.right.toFloat()
        val bt = r.bottom.toFloat()
        val outerTL = if (sunken) 0xFF808080.toInt() else 0xFFFFFFFF.toInt()
        val outerBR = if (sunken) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
        val innerTL = if (sunken) 0xFF000000.toInt() else 0xFFDFDFDF.toInt()
        val innerBR = if (sunken) 0xFFDFDFDF.toInt() else 0xFF808080.toInt()
        fun frame(inset: Float, tl: Int, br: Int) {
            paint.color = tl
            canvas.drawRect(l + inset, tp + inset, rt - inset, tp + inset + t, paint)
            canvas.drawRect(l + inset, tp + inset, l + inset + t, bt - inset, paint)
            paint.color = br
            canvas.drawRect(l + inset, bt - inset - t, rt - inset, bt - inset, paint)
            canvas.drawRect(rt - inset - t, tp + inset, rt - inset, bt - inset, paint)
        }
        frame(0f, outerTL, outerBR)
        frame(t, innerTL, innerBR)
    }
}
