package com.materialyou.keyboard

import android.content.Context

/**
 * Frequency dictionary: asset file with one lowercase word per line, most frequent first.
 * Gives prefix completions and spelling corrections (Damerau-Levenshtein, distance <= 2).
 * load() is meant to run on a background thread; all other methods are read-only afterwards.
 */
class WordDict(private val ctx: Context, private val asset: String) {

    class Cand(val word: String, val dist: Int, val cost: Int, val rank: Int)

    @Volatile
    var ready = false
        private set

    private var words: Array<String> = emptyArray()          // by rank
    private var masks: IntArray = IntArray(0)                // by rank
    private var sorted: Array<String> = emptyArray()         // alphabetical
    private var sortedRank: IntArray = IntArray(0)           // rank of sorted[i]
    private var byLen: Array<IntArray> = emptyArray()        // ranks per length
    private val rank = HashMap<String, Int>()

    fun load() {
        if (ready) return
        val list = ArrayList<String>(60000)
        ctx.assets.open(asset).bufferedReader(Charsets.UTF_8).use { r ->
            r.forEachLine { line ->
                val w = line.trim()
                if (w.isNotEmpty()) list.add(w)
            }
        }
        val n = list.size
        words = list.toTypedArray()
        masks = IntArray(n) { mask(words[it]) }
        for (i in 0 until n) if (!rank.containsKey(words[i])) rank[words[i]] = i

        val idx = (0 until n).sortedBy { words[it] }
        sorted = Array(n) { words[idx[it]] }
        sortedRank = IntArray(n) { idx[it] }

        val maxLen = 32
        val counts = IntArray(maxLen)
        for (w in words) counts[minOf(w.length, maxLen - 1)]++
        val buckets = Array(maxLen) { IntArray(counts[it]) }
        val fill = IntArray(maxLen)
        for (i in 0 until n) {
            val l = minOf(words[i].length, maxLen - 1)
            buckets[l][fill[l]++] = i
        }
        byLen = buckets
        ready = true
    }

    fun contains(w: String): Boolean = rank.containsKey(w)

    /** The [n] most frequent words. */
    fun top(n: Int): List<String> = if (!ready) emptyList() else words.asList().subList(0, minOf(n, words.size))

    /**
     * Swipe typing: [seq] is the sequence of letter keys the finger passed over (consecutive repeats removed).
     * A word matches when its letters (doubles collapsed) are a subsequence of [seq], it starts with the first key
     * and ends with the last one. Best first: well-covered paths and frequent words win.
     */
    fun swipe(seq: String, n: Int): List<String> {
        if (!ready || seq.length < 2) return emptyList()
        val first = seq[0]
        val last = seq[seq.length - 1]
        val strict = ArrayList<Pair<Float, String>>()
        val loose = ArrayList<Pair<Float, String>>()
        for (r in words.indices) {
            val w = words[r]
            if (w.length < 2 || (if (w[0] == 'ё') 'е' else w[0]) != first) continue
            var si = 0
            var prev = '\u0000'
            var cnt = 0
            var ok = true
            var lastCh = first
            for (ch0 in w) {
                val ch = if (ch0 == 'ё') 'е' else ch0
                if (ch == prev) continue
                prev = ch
                cnt++
                var found = false
                while (si < seq.length) {
                    if (seq[si] == ch) {
                        found = true
                        si++
                        break
                    }
                    si++
                }
                if (!found) {
                    ok = false
                    break
                }
                lastCh = ch
            }
            if (!ok || cnt < 2) continue
            val cover = cnt.toFloat() / seq.length
            val score = cover * 2f + 1f / Math.log(r + 3.0).toFloat()
            if (lastCh == last) strict.add(score to w) else loose.add(score - 0.6f to w)
        }
        val pool = if (strict.isNotEmpty()) strict else loose
        pool.sortByDescending { it.first }
        val out = ArrayList<String>(n)
        for (e in pool) {
            if (out.size >= n) break
            if (!out.contains(e.second)) out.add(e.second)
        }
        return out
    }

    /** Top [n] words starting with [prefix] (the word itself included if present), by frequency. */
    fun complete(prefix: String, n: Int): List<String> {
        if (!ready || prefix.isEmpty()) return emptyList()
        var lo = 0
        var hi = sorted.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (sorted[mid] < prefix) lo = mid + 1 else hi = mid
        }
        val best = IntArray(n) { Int.MAX_VALUE }
        var i = lo
        while (i < sorted.size && sorted[i].startsWith(prefix)) {
            val r = sortedRank[i]
            if (r < best[n - 1]) {
                var j = n - 1
                while (j > 0 && best[j - 1] > r) {
                    best[j] = best[j - 1]
                    j--
                }
                best[j] = r
            }
            i++
        }
        val out = ArrayList<String>(n)
        for (r in best) if (r != Int.MAX_VALUE) out.add(words[r])
        return out
    }

    /** Words within [maxDist] edits of [w], best first. */
    fun corrections(w: String, maxDist: Int, limit: Int): List<Cand> {
        if (!ready || w.isEmpty()) return emptyList()
        val wm = mask(w)
        val len = w.length
        val found = ArrayList<Cand>()
        for (l in (len - maxDist)..(len + maxDist)) {
            if (l < 1 || l >= byLen.size) continue
            for (r in byLen[l]) {
                if (Integer.bitCount(masks[r] xor wm) > 2 * maxDist) continue
                val cand = words[r]
                if (cand == w) continue
                val dist = osa(w, cand, maxDist)
                if (dist > maxDist) continue
                val cost = dist * 2 + (if (cand[0] == w[0]) 0 else 1)
                found.add(Cand(cand, dist, cost, r))
            }
        }
        found.sortWith(compareBy<Cand> { it.cost }.thenBy { it.rank })
        return if (found.size > limit) found.subList(0, limit) else found
    }

    private fun mask(s: String): Int {
        var m = 0
        for (c in s) m = m or (1 shl (c.code and 31))
        return m
    }

    /** Optimal string alignment distance with early exit. */
    private fun osa(a: String, b: String, max: Int): Int {
        val n = a.length
        val m = b.length
        if (Math.abs(n - m) > max) return max + 1
        var prev2 = IntArray(m + 1)
        var prev = IntArray(m + 1) { it }
        var cur = IntArray(m + 1)
        for (i in 1..n) {
            cur[0] = i
            var rowMin = cur[0]
            val ca = a[i - 1]
            for (j in 1..m) {
                val cost = if (ca == b[j - 1]) 0 else 1
                var v = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if (i > 1 && j > 1 && ca == b[j - 2] && a[i - 2] == b[j - 1]) {
                    v = minOf(v, prev2[j - 2] + 1)
                }
                cur[j] = v
                if (v < rowMin) rowMin = v
            }
            if (rowMin > max) return max + 1
            val t = prev2
            prev2 = prev
            prev = cur
            cur = t
        }
        return prev[m]
    }
}
