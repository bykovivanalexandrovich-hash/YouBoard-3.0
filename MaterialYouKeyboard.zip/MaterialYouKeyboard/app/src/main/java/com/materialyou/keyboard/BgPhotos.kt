package com.materialyou.keyboard

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.Uri
import java.io.File

/** The user's own photos for the keyboard background (stored privately in the app's files). */
object BgPhotos {
    const val ON = "bg_photo_on"
    const val SEL = "bg_sel"

    private var cacheKey: String? = null
    private var cacheBmp: Bitmap? = null

    fun dir(ctx: Context): File = File(ctx.filesDir, "bg").also { it.mkdirs() }

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles { f -> f.extension == "jpg" }?.sortedBy { it.name } ?: emptyList()

    /** Decodes the picked image (scaled down) and saves it; returns the new file or null. */
    fun add(ctx: Context, uri: Uri): File? {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            while (maxOf(opts.outWidth, opts.outHeight) / sample > 2400) sample *= 2
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return null
            val max = 1600f
            val k = minOf(1f, max / maxOf(bmp.width, bmp.height))
            val out = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
            val f = File(dir(ctx), "bg_${System.currentTimeMillis()}.jpg")
            f.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            f
        } catch (_: Throwable) {
            null
        }
    }

    /** Small preview for the gallery tiles. */
    fun thumb(f: File): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > 480) s *= 2
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (_: Throwable) {
        null
    }

    /** The selected photo as a keyboard background, or null when the mode is off / nothing is chosen. */
    fun drawable(ctx: Context, p: SharedPreferences, scrim: Int): Drawable? {
        if (!p.getBoolean(ON, false)) return null
        val name = p.getString(SEL, null) ?: return null
        val f = File(dir(ctx), name)
        if (!f.exists()) return null
        val key = name + f.lastModified()
        if (key != cacheKey) {
            cacheBmp = try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, o)
                var s = 1
                while (maxOf(o.outWidth, o.outHeight) / s > 1400) s *= 2
                BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
            } catch (_: Throwable) {
                null
            }
            cacheKey = key
        }
        val b = cacheBmp ?: return null
        return PhotoBgDrawable(b, scrim)
    }

    fun signature(p: SharedPreferences) = "${p.getBoolean(ON, false)}${p.getString(SEL, "")}"
}
