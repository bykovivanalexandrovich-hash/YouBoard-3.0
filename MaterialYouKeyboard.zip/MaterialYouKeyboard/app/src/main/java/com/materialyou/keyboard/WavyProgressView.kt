package com.materialyou.keyboard

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Material 3 expressive circular progress: a plain arc followed by a wavy one, spinning around. */
class WavyProgressView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private val d = resources.displayMetrics.density
    private val stroke = 4f * d
    private val plain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = stroke
        color = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF6750A4.toInt())
    }
    private val wavy = Paint(plain).apply {
        color = ColorUtils.blendARGB(plain.color, 0xFFFFFFFF.toInt(), 0.55f)
    }
    private val rect = RectF()
    private val path = Path()
    private var rot = 0f
    private var phase = 0f
    private var anim: ValueAnimator? = null

    override fun onMeasure(w: Int, h: Int) {
        val def = (40 * d).toInt()
        val sw = resolveSize(def, w)
        val sh = resolveSize(def, h)
        val s = minOf(sw, sh)
        setMeasuredDimension(s, s)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                rot = f * 360f
                phase = f * 2f * PI.toFloat() * 2f
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val amp = 2.2f * d
        val r = minOf(width, height) / 2f - stroke / 2f - amp
        if (r <= 0f) return
        val cx = width / 2f
        val cy = height / 2f
        rect.set(cx - r, cy - r, cx + r, cy + r)
        val start = rot - 90f
        // plain arc
        c.drawArc(rect, start, 235f, false, plain)
        // wavy arc in the remaining part of the circle
        val a0 = start + 235f + 24f
        val sweep = 360f - 235f - 48f
        path.reset()
        var a = 0f
        while (a <= sweep) {
            val ang = Math.toRadians((a0 + a).toDouble())
            val rr = r + amp * sin(a / sweep * 2f * PI.toFloat() * 3f + phase)
            val x = cx + rr * cos(ang).toFloat()
            val y = cy + rr * sin(ang).toFloat()
            if (a == 0f) path.moveTo(x, y) else path.lineTo(x, y)
            a += 2f
        }
        c.drawPath(path, wavy)
    }
}
