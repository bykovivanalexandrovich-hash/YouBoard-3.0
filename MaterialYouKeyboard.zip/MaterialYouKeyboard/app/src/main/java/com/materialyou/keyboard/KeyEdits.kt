package com.materialyou.keyboard

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * User edits of the main (letters) keyboard: order of keys, hidden keys, fixed colours and widths.
 * Stored per language as JSON in the pref "ke_<code>". The service and the editor screen share this model.
 */
object KeyEdits {

    const val SHIFT = "@shift"
    const val BKSP = "@bksp"
    const val MODE = "@mode"
    const val MENU = "@menu"
    const val SPACE = "@space"
    const val ENTER = "@enter"

    class Conf(
        var order: List<List<String>>?,
        val hide: MutableSet<String>,
        val color: MutableMap<String, Int>,
        val scale: MutableMap<String, Float>,
        val shape: MutableMap<String, String> = HashMap()
    ) {
        fun isEmpty() = order == null && hide.isEmpty() && color.isEmpty() && scale.isEmpty() && shape.isEmpty()
    }

    /** One key placed in a row. [w] is the final weight (scale applied), [hidden] keys are not drawn by the keyboard. */
    class Placed(val id: String, val w: Float, val hidden: Boolean)

    class Layout(val rows: List<List<Placed>>, val maxKeys: Float)

    private fun pref(code: String) = "ke_$code"

    fun load(p: SharedPreferences, code: String): Conf? {
        val s = p.getString(pref(code), null) ?: return null
        return try {
            val j = JSONObject(s)
            var order: List<List<String>>? = null
            j.optJSONArray("o")?.let { arr ->
                order = (0 until arr.length()).map { i ->
                    val r = arr.getJSONArray(i)
                    (0 until r.length()).map { r.getString(it) }
                }
            }
            val hide = HashSet<String>()
            j.optJSONArray("h")?.let { for (i in 0 until it.length()) hide.add(it.getString(i)) }
            val color = HashMap<String, Int>()
            j.optJSONObject("c")?.let { o -> o.keys().forEach { k -> color[k] = o.getInt(k) } }
            val scale = HashMap<String, Float>()
            j.optJSONObject("s")?.let { o -> o.keys().forEach { k -> scale[k] = o.getDouble(k).toFloat() } }
            val shape = HashMap<String, String>()
            j.optJSONObject("p")?.let { o -> o.keys().forEach { k -> shape[k] = o.getString(k) } }
            Conf(order, hide, color, scale, shape)
        } catch (_: Throwable) {
            null
        }
    }

    fun save(p: SharedPreferences, code: String, c: Conf?) {
        if (c == null || c.isEmpty()) {
            p.edit().remove(pref(code)).apply()
            return
        }
        val j = JSONObject()
        c.order?.let { o -> j.put("o", JSONArray().also { a -> o.forEach { r -> a.put(JSONArray(r)) } }) }
        j.put("h", JSONArray(c.hide.toList()))
        j.put("c", JSONObject().also { o -> c.color.forEach { (k, v) -> o.put(k, v) } })
        j.put("s", JSONObject().also { o -> c.scale.forEach { (k, v) -> o.put(k, v.toDouble()) } })
        j.put("p", JSONObject().also { o -> c.shape.forEach { (k, v) -> o.put(k, v) } })
        p.edit().putString(pref(code), j.toString()).apply()
    }

    fun active(p: SharedPreferences, code: String): Boolean = p.contains(pref(code))

    /** Changes the keyboard rebuilds on. */
    fun signature(p: SharedPreferences): String =
        p.all.entries.filter { it.key.startsWith("ke_") }.sortedBy { it.key }.joinToString("") { it.key + it.value }

    /** Keys in the factory order (no symbols mode): number row, three letter rows with shift/backspace, bottom row. */
    fun defaultOrder(p: SharedPreferences, code: String, numberRow: Boolean, hardAlt: Boolean): List<List<String>> {
        val letters = Layouts.rows(p, code).map { if (hardAlt) it.replace("ъ", "") else it }
        val out = ArrayList<List<String>>()
        if (numberRow) out.add("1234567890".map { it.toString() })
        letters.forEachIndexed { i, r ->
            val row = r.map { it.toString() }
            out.add(if (i == 2) listOf(SHIFT) + row + listOf(BKSP) else row)
        }
        out.add(listOf(MODE, MENU, ",", SPACE, ".", ENTER))
        return out
    }

    private fun sameKeys(a: List<List<String>>, b: List<List<String>>) =
        a.flatten().sorted() == b.flatten().sorted()

    /** The arrangement to show: the saved order if it still fits the current layout, otherwise the factory one. */
    fun layout(p: SharedPreferences, code: String, numberRow: Boolean, hardAlt: Boolean): Layout {
        val def = defaultOrder(p, code, numberRow, hardAlt)
        val conf = load(p, code)
        val order = conf?.order?.takeIf { sameKeys(it, def) } ?: def
        val letters = Layouts.rows(p, code).map { if (hardAlt) it.replace("ъ", "") else it }
        val maxKeys = letters.maxOf { it.length }.toFloat()
        val shiftW = if (letters.size > 2) ((maxKeys - letters[2].length) / 2f).coerceAtLeast(1f) else 1.5f
        fun base(id: String): Float = when (id) {
            SHIFT, BKSP -> shiftW
            MODE, ENTER -> 1.25f
            SPACE -> 0f
            else -> if (id.length == 1 && id[0].isDigit()) maxKeys / 10f else 1f
        }
        val rows = order.map { row ->
            val items = row.map { id ->
                val s = conf?.scale?.get(id) ?: 1f
                Placed(id, base(id) * s, conf?.hide?.contains(id) == true)
            }
            if (items.any { it.id == SPACE }) {
                val others = items.filter { it.id != SPACE && !it.hidden }.sumOf { it.w.toDouble() }.toFloat()
                val s = conf?.scale?.get(SPACE) ?: 1f
                val spaceW = ((maxKeys - others).coerceAtLeast(1.5f)) * s
                items.map { if (it.id == SPACE) Placed(SPACE, spaceW, it.hidden) else it }
            } else items
        }
        return Layout(rows, maxKeys)
    }
}
