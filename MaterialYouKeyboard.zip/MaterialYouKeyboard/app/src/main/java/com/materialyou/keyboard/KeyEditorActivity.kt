package com.materialyou.keyboard

import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Keyboard editor: swap, recolour, widen / narrow and delete keys. Edits are stored per language (see KeyEdits). */
class KeyEditorActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private var d = 1f
    private var code = "EN"
    private var conf = KeyEdits.Conf(null, HashSet(), HashMap(), HashMap())
    private var sel: String? = null
    private var swapping = false

    private lateinit var board: LinearLayout
    private lateinit var tools: LinearLayout
    private lateinit var info: TextView
    private lateinit var sizeText: TextView
    private lateinit var delBtn: MaterialButton
    private lateinit var swapBtn: MaterialButton
    private lateinit var swatches: LinearLayout

    private class Pal(
        val bg: Int, val letter: Int, val function: Int, val onFunction: Int, val space: Int,
        val onSurface: Int, val primary: Int, val onPrimary: Int
    )

    private val colors = intArrayOf(
        0xFFE53935.toInt(), 0xFFD81B60.toInt(), 0xFF8E24AA.toInt(), 0xFF3949AB.toInt(), 0xFF1E88E5.toInt(),
        0xFF00ACC1.toInt(), 0xFF43A047.toInt(), 0xFFC0CA33.toInt(), 0xFFFDD835.toInt(), 0xFFFB8C00.toInt(),
        0xFF6D4C41.toInt(), 0xFF757575.toInt(), 0xFF212121.toInt(), 0xFFFAFAFA.toInt()
    )

    private fun dp(v: Int) = (v * d).toInt()
    private fun attr(a: Int, fb: Int) = MaterialColors.getColor(this, a, fb)
    private fun isDark() = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

    private fun pal(): Pal {
        val id = if (prefs.getBoolean("win95", false)) Themes.WIN95 else prefs.getString(Themes.KEY, "system") ?: "system"
        val t = Themes.colors(id, isDark())
        return Pal(
            t?.bg ?: attr(com.google.android.material.R.attr.colorSurfaceContainer, 0xFF2B2930.toInt()),
            t?.letter ?: attr(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF36343B.toInt()),
            t?.function ?: attr(com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt()),
            t?.onFunction ?: attr(com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt()),
            t?.space ?: attr(com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E.toInt()),
            t?.onSurface ?: attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt()),
            t?.primary ?: attr(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt()),
            t?.onPrimary ?: attr(com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72.toInt())
        )
    }

    private fun numberRow() = prefs.getBoolean("number_row", true)
    private fun hardAlt() = code == "RU" && prefs.getBoolean("hard_sign_alt", true)

    private fun btn(text: String, click: () -> Unit): MaterialButton =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            this.text = text
            setAllCaps(false)
            setOnClickListener { click() }
        }

    private fun rowOf(vararg v: View): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        v.forEachIndexed { i, x ->
            r.addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = dp(6)
            })
        }
        return r
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !isDark()
        val langs = Langs.enabled(this, prefs)
        code = langs.first().code

        val surface = attr(com.google.android.material.R.attr.colorSurface, 0xFF141218.toInt())
        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val muted = attr(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF938F99.toInt())

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(surface)
            fitsSystemWindows = true
        }
        val tb = MaterialToolbar(this).apply {
            title = getString(R.string.ke_title)
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { finish() }
        }
        root.addView(tb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(80))
        }
        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // language tabs
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val group = MaterialButtonToggleGroup(this).apply {
            isSingleSelection = true
            isSelectionRequired = true
        }
        val ids = HashMap<Int, String>()
        for (l in langs) {
            val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = l.code
                id = View.generateViewId()
                isCheckable = true
            }
            ids[b.id] = l.code
            group.addView(b)
        }
        hs.addView(group)
        col.addView(hs)

        // keyboard preview
        board = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val g = GradientDrawable()
            g.cornerRadius = dp(22).toFloat()
            g.setColor(pal().bg)
            background = g
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        col.addView(board, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(12)
        })

        info = TextView(this).apply {
            textSize = 15f
            setTextColor(onSurface)
        }
        col.addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(14)
        })

        // tools for the selected key
        tools = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tools, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        })

        swapBtn = btn(getString(R.string.ke_swap)) {
            swapping = !swapping
            updateTools()
        }
        tools.addView(rowOf(
            btn(getString(R.string.ke_left)) { moveBy(-1) },
            btn(getString(R.string.ke_right)) { moveBy(1) },
            swapBtn
        ))

        sizeText = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(onSurface)
        }
        val sizeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        sizeRow.addView(TextView(this).apply {
            text = getString(R.string.ke_width)
            textSize = 14f
            setTextColor(muted)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sizeRow.addView(btn("−") { scaleBy(-0.25f) }, LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT))
        sizeRow.addView(sizeText, LinearLayout.LayoutParams(dp(72), ViewGroup.LayoutParams.WRAP_CONTENT))
        sizeRow.addView(btn("+") { scaleBy(0.25f) }, LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT))
        tools.addView(sizeRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        })

        tools.addView(TextView(this).apply {
            text = getString(R.string.ke_color)
            textSize = 14f
            setTextColor(muted)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(12)
        })
        val sh = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sh.addView(swatches)
        tools.addView(sh, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        })

        delBtn = btn(getString(R.string.ke_del)) { toggleHide() }
        tools.addView(delBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(12)
        })

        col.addView(TextView(this).apply {
            text = getString(R.string.ke_warn)
            textSize = 12f
            setTextColor(muted)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(16)
        })
        col.addView(btn(getString(R.string.ke_reset)) {
            MaterialAlertDialogBuilder(this)
                .setMessage(R.string.ke_reset_q)
                .setPositiveButton(R.string.ke_yes) { _, _ ->
                    KeyEdits.save(prefs, code, null)
                    selectLang(code)
                }
                .setNegativeButton(R.string.ke_no, null)
                .show()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        })

        setContentView(root)

        group.check(ids.entries.first { it.value == code }.key)
        group.addOnButtonCheckedListener { _, id, checked ->
            if (checked) ids[id]?.let { selectLang(it) }
        }
        selectLang(code)
    }

    private fun selectLang(c: String) {
        code = c
        conf = KeyEdits.load(prefs, c) ?: KeyEdits.Conf(null, HashSet(), HashMap(), HashMap())
        sel = null
        swapping = false
        render()
    }

    private fun label(id: String): String = when (id) {
        KeyEdits.SHIFT -> "⇧"
        KeyEdits.BKSP -> "⌫"
        KeyEdits.MODE -> "?123"
        KeyEdits.MENU -> "☰"
        KeyEdits.SPACE -> Langs.byCode[code]?.title ?: code
        KeyEdits.ENTER -> "↵"
        else -> id
    }

    private fun name(id: String): String = getString(
        when (id) {
            KeyEdits.SHIFT -> R.string.ke_k_shift
            KeyEdits.BKSP -> R.string.ke_k_bksp
            KeyEdits.MODE -> R.string.ke_k_mode
            KeyEdits.MENU -> R.string.ke_k_menu
            KeyEdits.SPACE -> R.string.ke_k_space
            KeyEdits.ENTER -> R.string.ke_k_enter
            else -> R.string.ke_k_key
        }
    ) + if (id.startsWith("@")) "" else " «$id»"

    private fun layout() = KeyEdits.layout(prefs, code, numberRow(), hardAlt())

    private fun orderNow(): MutableList<MutableList<String>> =
        layout().rows.map { r -> r.map { it.id }.toMutableList() }.toMutableList()

    private fun commit(order: List<List<String>>?) {
        val def = KeyEdits.defaultOrder(prefs, code, numberRow(), hardAlt())
        conf.order = if (order == null || order == def) null else order
        KeyEdits.save(prefs, code, conf)
        render()
    }

    private fun save() {
        KeyEdits.save(prefs, code, conf)
        render()
    }

    private fun moveBy(dir: Int) {
        val id = sel ?: return
        val o = orderNow()
        for (r in o) {
            val i = r.indexOf(id)
            if (i < 0) continue
            val j = i + dir
            if (j < 0 || j >= r.size) return
            val t = r[i]; r[i] = r[j]; r[j] = t
            commit(o)
            return
        }
    }

    private fun swap(a: String, b: String) {
        val o = orderNow()
        var ra = -1; var ia = -1; var rb = -1; var ib = -1
        for (r in o.indices) {
            o[r].indexOf(a).let { if (it >= 0) { ra = r; ia = it } }
            o[r].indexOf(b).let { if (it >= 0) { rb = r; ib = it } }
        }
        if (ra < 0 || rb < 0) return
        o[ra][ia] = b
        o[rb][ib] = a
        commit(o)
    }

    private fun scaleBy(delta: Float) {
        val id = sel ?: return
        val v = (Math.round(((conf.scale[id] ?: 1f) + delta) * 100f) / 100f).coerceIn(0.5f, 2.5f)
        if (Math.abs(v - 1f) < 0.01f) conf.scale.remove(id) else conf.scale[id] = v
        save()
    }

    private fun toggleHide() {
        val id = sel ?: return
        if (!conf.hide.remove(id)) conf.hide.add(id)
        save()
    }

    private fun setColor(c: Int?) {
        val id = sel ?: return
        if (c == null) conf.color.remove(id) else conf.color[id] = c
        save()
    }

    private fun onTap(id: String) {
        val s = sel
        if (swapping && s != null && s != id) {
            swapping = false
            swap(s, id)
            return
        }
        sel = id
        swapping = false
        render()
    }

    private fun baseColor(id: String, p: Pal): Pair<Int, Int> = when (id) {
        KeyEdits.SHIFT, KeyEdits.BKSP, KeyEdits.MODE, KeyEdits.MENU -> p.function to p.onFunction
        KeyEdits.SPACE -> p.space to p.onSurface
        KeyEdits.ENTER -> p.primary to p.onPrimary
        else -> p.letter to p.onSurface
    }

    private fun render() {
        board.removeAllViews()
        val p = pal()
        val primary = attr(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt())
        val lay = layout()
        for (row in lay.rows) {
            val sum = row.sumOf { if (it.hidden) 0.8 else it.w.toDouble() }.toFloat()
            val pad = if (row.none { it.id == KeyEdits.SPACE && !it.hidden } && sum < lay.maxKeys) (lay.maxKeys - sum) / 2f else 0f
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = maxOf(sum + 2f * pad, 0.1f)
            }
            board.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
            if (pad > 0f) r.addView(View(this), LinearLayout.LayoutParams(0, 1, pad))
            for (k in row) {
                val custom = conf.color[k.id]
                val base = baseColor(k.id, p)
                val bg = custom ?: base.first
                val fg = if (custom != null) (if (ColorUtils.calculateLuminance(custom) > 0.5) 0xFF1B1B1F.toInt() else 0xFFFFFFFF.toInt()) else base.second
                val tv = TextView(this).apply {
                    text = label(k.id)
                    gravity = Gravity.CENTER
                    setTextColor(fg)
                    textSize = if (k.id.length > 1) 12f else 16f
                    maxLines = 1
                    alpha = if (k.hidden) 0.35f else 1f
                    background = GradientDrawable().apply {
                        cornerRadius = dp(9).toFloat()
                        setColor(bg)
                        if (k.id == sel) setStroke(dp(3), primary)
                        else if (k.hidden) setStroke(dp(1), fg)
                    }
                    setOnClickListener { onTap(k.id) }
                }
                r.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, if (k.hidden) 0.8f else k.w).apply {
                    setMargins(dp(2), dp(3), dp(2), dp(3))
                })
            }
            if (pad > 0f) r.addView(View(this), LinearLayout.LayoutParams(0, 1, pad))
        }
        updateTools()
    }

    private fun updateTools() {
        val id = sel
        if (id == null) {
            tools.visibility = View.GONE
            info.text = getString(R.string.ke_hint)
            return
        }
        tools.visibility = View.VISIBLE
        info.text = if (swapping) getString(R.string.ke_swap_on, name(id)) else name(id)
        swapBtn.alpha = if (swapping) 0.6f else 1f
        sizeText.text = "${Math.round((conf.scale[id] ?: 1f) * 100f)}%"
        delBtn.text = getString(if (conf.hide.contains(id)) R.string.ke_restore else R.string.ke_del)

        swatches.removeAllViews()
        val cur = conf.color[id]
        val primary = attr(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt())
        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        fun dot(c: Int?, text: String?) {
            val tv = TextView(this).apply {
                gravity = Gravity.CENTER
                this.text = text ?: ""
                textSize = 11f
                setTextColor(onSurface)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    if (c != null) setColor(c)
                    setStroke(if (cur == c) dp(3) else dp(1), if (cur == c) primary else onSurface and 0x55FFFFFF)
                }
                setOnClickListener { setColor(c) }
            }
            swatches.addView(tv, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(8) })
        }
        dot(null, getString(R.string.ke_auto))
        for (c in colors) dot(c, null)
    }
}
