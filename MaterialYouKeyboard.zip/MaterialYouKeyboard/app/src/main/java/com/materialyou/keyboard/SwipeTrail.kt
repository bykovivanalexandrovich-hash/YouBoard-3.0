package com.materialyou.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** The line drawn under the finger while swipe typing. Points are screen coordinates. */
class SwipeTrail(ctx: Context, color: Int, width: Float) : View(ctx) {
    private val xs = ArrayList<Float>()
    private val ys = ArrayList<Float>()
    private val path = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = width
        this.color = color
    }
    private val loc = IntArray(2)

    init {
        isClickable = false
        isFocusable = false
        visibility = GONE
    }

    /**
     * [h] = exact height of the key area. A MATCH_PARENT child of a WRAP_CONTENT FrameLayout is measured at the
     * full available height and would stretch the whole keyboard window to the screen, so the height is fixed.
     */
    fun start(x: Float, y: Float, h: Int) {
        animate().cancel()
        val lp = layoutParams
        if (lp != null && h > 0 && lp.height != h) {
            lp.height = h
            layoutParams = lp
        }
        xs.clear()
        ys.clear()
        alpha = 0.85f
        visibility = VISIBLE
        add(x, y)
    }

    fun add(x: Float, y: Float) {
        xs.add(x)
        ys.add(y)
        if (xs.size > 26) {
            xs.removeAt(0)
            ys.removeAt(0)
        }
        invalidate()
    }

    fun fade() {
        animate().alpha(0f).setDuration(260).withEndAction {
            visibility = GONE
            xs.clear()
            ys.clear()
        }.start()
    }

    override fun onDraw(canvas: Canvas) {
        if (xs.size < 2) return
        getLocationOnScreen(loc)
        path.reset()
        val maxX = width.toFloat()
        val maxY = height.toFloat()
        path.moveTo((xs[0] - loc[0]).coerceIn(0f, maxX), (ys[0] - loc[1]).coerceIn(0f, maxY))
        for (i in 1 until xs.size) {
            val px = (xs[i - 1] - loc[0]).coerceIn(0f, maxX)
            val py = (ys[i - 1] - loc[1]).coerceIn(0f, maxY)
            val cx = (xs[i] - loc[0]).coerceIn(0f, maxX)
            val cy = (ys[i] - loc[1]).coerceIn(0f, maxY)
            path.quadTo(px, py, (px + cx) / 2f, (py + cy) / 2f)
        }
        canvas.drawPath(path, paint)
    }
}
