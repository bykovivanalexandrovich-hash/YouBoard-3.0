package com.materialyou.keyboard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Shows the last crash report (runs in its own process, so it still opens when the app itself keeps crashing). */
class CrashActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = File(filesDir, App.CRASH_FILE)
        val text = try {
            f.readText()
        } catch (_: Throwable) {
            ""
        }
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121212"))
            setPadding((16 * d).toInt(), (36 * d).toInt(), (16 * d).toInt(), (16 * d).toInt())
        }
        root.addView(TextView(this).apply {
            this.text = "Приложение вылетело / The app crashed"
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            this.text = "Нажми «Копировать» и отправь текст разработчику / Tap Copy and send the text"
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, (4 * d).toInt(), 0, (10 * d).toInt())
        })
        val scroll = ScrollView(this)
        scroll.addView(TextView(this).apply {
            this.text = text
            setTextColor(Color.parseColor("#FF8A80"))
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
        })
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply {
            this.text = "Копировать / Copy"
            setOnClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("crash", text))
                Toast.makeText(this@CrashActivity, "OK", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply {
            this.text = "Закрыть / Close"
            setOnClickListener {
                f.delete()
                finish()
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)
        setContentView(root)
    }
}
