package com.materialyou.keyboard

import android.content.SharedPreferences
import android.content.res.Resources

/** UI language helper for code that cannot use resources (the keyboard service). */
object Loc {
    const val KEY = "ui_lang" // "system" | "ru" | "en"

    fun isRu(prefs: SharedPreferences): Boolean = when (prefs.getString(KEY, "system")) {
        "ru" -> true
        "en" -> false
        else -> Resources.getSystem().configuration.locales.get(0)?.language == "ru"
    }

    fun t(prefs: SharedPreferences, ru: String, en: String): String = if (isRu(prefs)) ru else en
}
