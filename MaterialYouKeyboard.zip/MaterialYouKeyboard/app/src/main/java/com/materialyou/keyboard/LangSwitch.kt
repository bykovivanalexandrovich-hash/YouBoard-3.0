package com.materialyou.keyboard

import android.content.SharedPreferences

/** How the keyboard language is switched: "button" (the language key: tap switches, hold opens emoji), "globe" (button under the keys), "swipe" (along the space bar). */
object LangSwitch {
    const val KEY = "lang_switch"
    val IDS = listOf("globe", "swipe", "button")

    fun mode(p: SharedPreferences): String {
        p.getString(KEY, null)?.let { if (it in IDS) return it }
        // older versions stored two separate switches
        return when {
            p.getBoolean("lang_swipe", false) -> "swipe"
            p.getBoolean("lang_globe", false) -> "globe"
            else -> "button"
        }
    }
}
