package com.materialyou.keyboard

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.CompoundButton
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.google.android.material.color.MaterialColors
import com.google.android.material.slider.Slider
import kotlin.math.abs
import kotlin.math.sin

/**
 * Floating, opaque tab bar at the bottom of the app screens: Settings, Control Center, Update log.
 * The highlighted "capsule" flows from the old tab to the new one, and a horizontal swipe on the
 * screen turns to the neighbouring tab. Colours come from the current (light or dark) Material theme.
 */
object BottomBar {
    const val SETTINGS = 0
    const val THEMES = 1
    const val CONTROL = 2
    const val LOG = 3
    const val EXTRA_FROM = "bar_from"

    fun attach(act: Activity, selected: Int): Controller = Controller(act, selected)

    class Controller(private val act: Activity, private val selected: Int) {
        val view: View
        private val d = act.resources.displayMetrics.density
        private val indicator: View
        private val items = ArrayList<LinearLayout>()
        private val icons = ArrayList<ImageView>()
        private val labels = ArrayList<TextView>()
        private val labelW = IntArray(4)
        private val selFg: Int
        private val fg: Int
        private val ev = ArgbEvaluator()
        private var anim: ValueAnimator? = null
        private var blocked = false

        private fun dp(v: Int) = (v * d).toInt()

        /** Width of a tab whose label is [f] (0..1) of the way out: only the icon when closed. */
        private fun itemW(i: Int, f: Float): Int = dp(24) + dp(24) + (f * (dp(6) + labelW[i])).toInt()

        private fun left(i: Int, f: FloatArray): Float {
            var x = dp(2).toFloat()
            for (j in 0 until i) x += itemW(j, f[j]) + dp(4)
            return x
        }

        private fun fractions(active: Int) = FloatArray(4) { if (it == active) 1f else 0f }

        init {
            val host = act.findViewById<ViewGroup>(android.R.id.content)
            fun color(attr: Int, fb: Int) = MaterialColors.getColor(host, attr, fb)
            val surface = color(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF2B2930.toInt())
            val outline = color(com.google.android.material.R.attr.colorOutlineVariant, 0xFF49454F.toInt())
            val selBg = color(com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt())
            selFg = color(com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt())
            fg = color(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())

            val pill = FrameLayout(act).apply {
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(40).toFloat()
                    setColor(surface)
                    setStroke(dp(1), outline)
                }
                elevation = dp(8).toFloat()
            }
            indicator = View(act).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(20).toFloat()
                    setColor(selBg)
                }
            }
            // fixed size on purpose: a MATCH_PARENT child would stretch the wrap-content bar over the whole screen
            pill.addView(indicator, FrameLayout.LayoutParams(dp(48), dp(40)))

            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tabs = listOf(
                Triple(SETTINGS, R.drawable.ic_settings, R.string.tab_settings),
                Triple(THEMES, R.drawable.ic_palette, R.string.tab_themes),
                Triple(CONTROL, R.drawable.ic_tune, R.string.tab_cc_bar),
                Triple(LOG, R.drawable.ic_log, R.string.tab_log_bar)
            )
            for ((id, icon, name) in tabs) {
                val item = LinearLayout(act).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), 0, dp(12), 0)
                    isClickable = true
                    isFocusable = true
                }
                val iv = ImageView(act).apply { setImageResource(icon) }
                item.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
                val tv = TextView(act).apply {
                    text = act.getString(name)
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    gravity = Gravity.CENTER_VERTICAL or Gravity.START
                    maxLines = 1
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                }
                labelW[id] = Math.ceil(tv.paint.measureText(tv.text.toString()).toDouble()).toInt() + dp(2)
                item.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT))
                item.setOnClickListener { if (id != selected) go(act, id, selected, false) }
                row.addView(item, LinearLayout.LayoutParams(dp(48), dp(40)).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                })
                items.add(item)
                icons.add(iv)
                labels.add(tv)
            }
            pill.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            lp.setMargins(dp(16), 0, dp(16), dp(12))
            host.addView(pill, lp)
            view = pill

            showState(selected)
            val from = act.intent?.getIntExtra(EXTRA_FROM, selected) ?: selected
            animateFrom(from)
        }

        /** Apply label fractions [f] to the tabs: widths, label size and alpha, colours. */
        private fun applyFractions(f: FloatArray) {
            for (i in items.indices) {
                val itm = items[i]
                val lp = itm.layoutParams as LinearLayout.LayoutParams
                lp.width = itemW(i, f[i])
                itm.layoutParams = lp
                val tv = labels[i]
                val tl = tv.layoutParams as LinearLayout.LayoutParams
                tl.width = (f[i] * labelW[i]).toInt()
                tl.marginStart = (dp(6) * f[i]).toInt()
                tv.layoutParams = tl
                tv.alpha = f[i]
                val c = ev.evaluate(f[i].coerceIn(0f, 1f), fg, selFg) as Int
                icons[i].setColorFilter(c)
                tv.setTextColor(c)
            }
        }

        private fun placeIndicator(x: Float, w: Float) {
            val lp = indicator.layoutParams
            if (lp.width != w.toInt()) {
                lp.width = w.toInt()
                indicator.layoutParams = lp
            }
            indicator.translationX = x
        }

        private fun showState(tab: Int) {
            val f = fractions(tab)
            applyFractions(f)
            placeIndicator(left(tab, f), itemW(tab, 1f).toFloat())
        }

        /** Put the capsule on tab [from] and let it flow to the current tab, the label of the old tab folds in while the new one slides out. */
        fun animateFrom(from: Int) {
            anim?.cancel()
            if (from == selected || from !in items.indices) {
                showState(selected)
                return
            }
            val fa = fractions(from)
            val fb = fractions(selected)
            val x0 = left(from, fa)
            val w0 = itemW(from, 1f).toFloat()
            val x1 = left(selected, fb)
            val w1 = itemW(selected, 1f).toFloat()
            showState(from)
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 420
                interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
                addUpdateListener {
                    val g = it.animatedValue as Float
                    applyFractions(FloatArray(4) { i -> fa[i] + (fb[i] - fa[i]) * g })
                    val w = w0 + (w1 - w0) * g
                    val cx = (x0 + w0 / 2f) + ((x1 + w1 / 2f) - (x0 + w0 / 2f)) * g
                    // the capsule stretches while it flows, like liquid
                    val ws = w * (1f + 0.22f * sin(Math.PI * g).toFloat())
                    placeIndicator(cx - ws / 2f, ws)
                }
                start()
            }
        }

        // ------------------------------------------------------------ swipe between tabs

        private val detector = GestureDetector(act, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || blocked || view.visibility != View.VISIBLE) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(vx) < 700 || abs(dx) < dp(70) || abs(dx) < abs(dy) * 1.8f) return false
                val next = selected + if (dx < 0) 1 else -1
                if (next !in 0..3) return false
                go(act, next, selected, true)
                return true
            }
        })

        /** Call from Activity.dispatchTouchEvent. Never consumes the event. */
        fun feed(ev: MotionEvent) {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                val root = act.window.decorView
                var v: View? = hit(root, ev.rawX.toInt(), ev.rawY.toInt())
                blocked = false
                while (v != null) {
                    if (v is GlowPad || v is Slider || v is SeekBar || v is HorizontalScrollView || v is CompoundButton) {
                        blocked = true
                        break
                    }
                    v = v.parent as? View
                }
            }
            detector.onTouchEvent(ev)
        }

        private fun hit(v: View, x: Int, y: Int): View? {
            if (v.visibility != View.VISIBLE) return null
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            if (x < loc[0] || x >= loc[0] + v.width || y < loc[1] || y >= loc[1] + v.height) return null
            if (v is ViewGroup) for (i in v.childCount - 1 downTo 0) hit(v.getChildAt(i), x, y)?.let { return it }
            return v
        }
    }

    @Suppress("DEPRECATION")
    private fun go(act: Activity, tab: Int, from: Int, swipe: Boolean) {
        val target = when (tab) {
            SETTINGS -> MainActivity::class.java
            THEMES -> ThemesActivity::class.java
            CONTROL -> ControlCenterActivity::class.java
            else -> ChangelogActivity::class.java
        }
        val i = Intent(act, target).putExtra(EXTRA_FROM, from)
        if (tab == SETTINGS) i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        act.startActivity(i)
        if (tab != SETTINGS && act !is MainActivity) act.finish()
        if (swipe) {
            if (tab > from) act.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            else act.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        } else {
            act.overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
        }
    }
}
