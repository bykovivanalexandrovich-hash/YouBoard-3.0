package com.materialyou.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.widget.TextViewCompat
import com.google.android.material.color.MaterialColors

/**
 * Floating, opaque tab bar at the bottom of the app screens: Settings, Control Center, Update log.
 * Colours come from the current (light or dark) Material theme.
 */
object BottomBar {
    const val SETTINGS = 0
    const val CONTROL = 1
    const val LOG = 2

    fun attach(act: Activity, selected: Int): View {
        val d = act.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val host = act.findViewById<ViewGroup>(android.R.id.content)
        fun color(attr: Int, fb: Int) = MaterialColors.getColor(host, attr, fb)

        val surface = color(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF2B2930.toInt())
        val outline = color(com.google.android.material.R.attr.colorOutlineVariant, 0xFF49454F.toInt())
        val selBg = color(com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt())
        val selFg = color(com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt())
        val fg = color(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())

        val pill = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(40).toFloat()
                setColor(surface)
                setStroke(dp(1), outline)
            }
            elevation = dp(8).toFloat()
        }

        val tabs = listOf(
            Triple(SETTINGS, R.drawable.ic_settings, R.string.tab_settings),
            Triple(CONTROL, R.drawable.ic_tune, R.string.menu_cc),
            Triple(LOG, R.drawable.ic_log, R.string.tab_log)
        )
        for ((id, icon, name) in tabs) {
            val on = id == selected
            val item = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(6), dp(8), dp(6), dp(8))
                isClickable = true
                isFocusable = true
                if (on) background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(30).toFloat()
                    setColor(selBg)
                }
            }
            val iv = ImageView(act).apply {
                setImageResource(icon)
                setColorFilter(if (on) selFg else fg)
            }
            item.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
            val tv = TextView(act).apply {
                text = act.getString(name)
                setTextColor(if (on) selFg else fg)
                typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                gravity = Gravity.CENTER
                maxLines = 1
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            }
            TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(tv, 9, 12, 1, TypedValue.COMPLEX_UNIT_SP)
            val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            tlp.topMargin = dp(3)
            item.addView(tv, tlp)
            item.setOnClickListener { if (!on) go(act, id) }
            pill.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            })
        }

        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        lp.setMargins(dp(16), 0, dp(16), dp(14))
        host.addView(pill, lp)
        ViewCompat.setElevation(pill, dp(8).toFloat())
        return pill
    }

    private fun go(act: Activity, tab: Int) {
        val target = when (tab) {
            SETTINGS -> MainActivity::class.java
            CONTROL -> ControlCenterActivity::class.java
            else -> ChangelogActivity::class.java
        }
        val i = Intent(act, target).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        if (tab == SETTINGS) {
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            act.startActivity(i)
        } else {
            act.startActivity(i)
            if (act !is MainActivity) act.finish()
        }
        @Suppress("DEPRECATION")
        act.overridePendingTransition(0, 0)
    }
}
