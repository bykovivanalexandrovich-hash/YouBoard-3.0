package com.materialyou.keyboard

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.CompoundButton
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.view.doOnLayout
import androidx.core.widget.TextViewCompat
import com.google.android.material.color.MaterialColors
import com.google.android.material.slider.Slider
import kotlin.math.abs
import kotlin.math.sin

/**
 * Floating, opaque tab bar at the bottom of the app screens: Settings, Control Center, Update log.
 * The highlighted "capsule" flows from the old tab to the new one, and a horizontal swipe on the
 * screen turns to the neighbouring tab. Colours come from the current (light or dark) Material theme.
 */
object BottomBar {
    const val SETTINGS = 0
    const val CONTROL = 1
    const val LOG = 2
    const val EXTRA_FROM = "bar_from"

    fun attach(act: Activity, selected: Int): Controller = Controller(act, selected)

    class Controller(private val act: Activity, private val selected: Int) {
        val view: View
        private val d = act.resources.displayMetrics.density
        private val indicator: View
        private val items = ArrayList<LinearLayout>()
        private val icons = ArrayList<ImageView>()
        private val labels = ArrayList<TextView>()
        private val selFg: Int
        private val fg: Int
        private var anim: ValueAnimator? = null
        private var blocked = false

        private fun dp(v: Int) = (v * d).toInt()

        init {
            val host = act.findViewById<ViewGroup>(android.R.id.content)
            fun color(attr: Int, fb: Int) = MaterialColors.getColor(host, attr, fb)
            val surface = color(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF2B2930.toInt())
            val outline = color(com.google.android.material.R.attr.colorOutlineVariant, 0xFF49454F.toInt())
            val selBg = color(com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt())
            selFg = color(com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt())
            fg = color(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())

            val pill = FrameLayout(act).apply {
                setPadding(dp(8), dp(8), dp(8), dp(8))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(40).toFloat()
                    setColor(surface)
                    setStroke(dp(1), outline)
                }
                elevation = dp(8).toFloat()
            }
            indicator = View(act).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(30).toFloat()
                    setColor(selBg)
                }
            }
            // fixed size on purpose: a MATCH_PARENT child would stretch the wrap-content bar over the whole screen
            pill.addView(indicator, FrameLayout.LayoutParams(dp(60), dp(1)))

            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tabs = listOf(
                Triple(SETTINGS, R.drawable.ic_settings, R.string.tab_settings),
                Triple(CONTROL, R.drawable.ic_tune, R.string.menu_cc),
                Triple(LOG, R.drawable.ic_log, R.string.tab_log)
            )
            for ((id, icon, name) in tabs) {
                val item = LinearLayout(act).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(6), dp(8), dp(6), dp(8))
                    isClickable = true
                    isFocusable = true
                }
                val iv = ImageView(act).apply { setImageResource(icon) }
                item.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
                val tv = TextView(act).apply {
                    text = act.getString(name)
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    gravity = Gravity.CENTER
                    maxLines = 1
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                }
                TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(tv, 9, 12, 1, TypedValue.COMPLEX_UNIT_SP)
                val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                tlp.topMargin = dp(3)
                item.addView(tv, tlp)
                item.setOnClickListener { if (id != selected) go(act, id, selected, false) }
                row.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                })
                items.add(item)
                icons.add(iv)
                labels.add(tv)
            }
            pill.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            lp.setMargins(dp(16), 0, dp(16), dp(14))
            host.addView(pill, lp)
            view = pill

            paint(selected)
            val from = act.intent?.getIntExtra(EXTRA_FROM, selected) ?: selected
            animateFrom(from)
        }

        private fun paint(sel: Int) {
            for (i in items.indices) {
                val c = if (i == sel) selFg else fg
                icons[i].setColorFilter(c)
                labels[i].setTextColor(c)
            }
        }

        private fun place(i: Int) {
            val it = items[i]
            val lp = indicator.layoutParams
            if (lp.width != it.width || lp.height != it.height) {
                lp.width = it.width
                lp.height = it.height
                indicator.layoutParams = lp
            }
            indicator.translationX = it.left.toFloat()
        }

        /** Put the capsule on tab [from] and let it flow to the current tab. */
        fun animateFrom(from: Int) {
            anim?.cancel()
            view.doOnLayout {
                val rowItem = items[selected]
                val lp = indicator.layoutParams
                lp.width = rowItem.width
                lp.height = items.maxOf { it.height }
                indicator.layoutParams = lp
                indicator.pivotX = rowItem.width / 2f
                if (from == selected || from !in items.indices) {
                    indicator.scaleX = 1f
                    place(selected)
                    paint(selected)
                    return@doOnLayout
                }
                val x0 = items[from].left.toFloat()
                val x1 = items[selected].left.toFloat()
                val ev = ArgbEvaluator()
                paint(from)
                anim = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 420
                    interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
                    addUpdateListener {
                        val f = it.animatedValue as Float
                        indicator.translationX = x0 + (x1 - x0) * f
                        // the capsule stretches while it flows, like liquid
                        indicator.scaleX = 1f + 0.22f * sin(Math.PI * f).toFloat()
                        for (i in items.indices) {
                            val a = if (i == from) selFg else if (i == selected) fg else fg
                            val b = if (i == selected) selFg else fg
                            val c = ev.evaluate(f, a, b) as Int
                            icons[i].setColorFilter(c)
                            labels[i].setTextColor(c)
                        }
                    }
                    start()
                }
            }
        }

        // ------------------------------------------------------------ swipe between tabs

        private val detector = GestureDetector(act, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || blocked || view.visibility != View.VISIBLE) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(vx) < 700 || abs(dx) < dp(70) || abs(dx) < abs(dy) * 1.8f) return false
                val next = selected + if (dx < 0) 1 else -1
                if (next !in 0..2) return false
                go(act, next, selected, true)
                return true
            }
        })

        /** Call from Activity.dispatchTouchEvent. Never consumes the event. */
        fun feed(ev: MotionEvent) {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                val root = act.window.decorView
                var v: View? = hit(root, ev.rawX.toInt(), ev.rawY.toInt())
                blocked = false
                while (v != null) {
                    if (v is Slider || v is SeekBar || v is HorizontalScrollView || v is CompoundButton) {
                        blocked = true
                        break
                    }
                    v = v.parent as? View
                }
            }
            detector.onTouchEvent(ev)
        }

        private fun hit(v: View, x: Int, y: Int): View? {
            if (v.visibility != View.VISIBLE) return null
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            if (x < loc[0] || x >= loc[0] + v.width || y < loc[1] || y >= loc[1] + v.height) return null
            if (v is ViewGroup) for (i in v.childCount - 1 downTo 0) hit(v.getChildAt(i), x, y)?.let { return it }
            return v
        }
    }

    @Suppress("DEPRECATION")
    private fun go(act: Activity, tab: Int, from: Int, swipe: Boolean) {
        val target = when (tab) {
            SETTINGS -> MainActivity::class.java
            CONTROL -> ControlCenterActivity::class.java
            else -> ChangelogActivity::class.java
        }
        val i = Intent(act, target).putExtra(EXTRA_FROM, from)
        if (tab == SETTINGS) i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        act.startActivity(i)
        if (tab != SETTINGS && act !is MainActivity) act.finish()
        if (swipe) {
            if (tab > from) act.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            else act.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        } else {
            act.overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
        }
    }
}
