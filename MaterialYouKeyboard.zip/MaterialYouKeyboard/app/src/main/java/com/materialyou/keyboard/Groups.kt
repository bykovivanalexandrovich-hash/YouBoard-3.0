package com.materialyou.keyboard

import android.animation.ValueAnimator
import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors

/** Chevron that turns smoothly: progress 0 = pointing down (closed), 1 = pointing up (open). */
class ArrowDrawable(color: Int, private val size: Int) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        this.color = color
    }
    var progress = 0f
        set(v) {
            field = v
            invalidateSelf()
        }

    override fun draw(c: Canvas) {
        val b = bounds
        val cx = b.exactCenterX()
        val cy = b.exactCenterY()
        val s = b.width() * 0.24f
        paint.strokeWidth = b.width() * 0.10f
        c.save()
        c.rotate(180f * progress, cx, cy)
        val p = Path().apply {
            moveTo(cx - s, cy - s / 2f)
            lineTo(cx, cy + s / 2f)
            lineTo(cx + s, cy - s / 2f)
        }
        c.drawPath(p, paint)
        c.restore()
    }

    override fun getIntrinsicWidth() = size
    override fun getIntrinsicHeight() = size
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** Collapsible groups: gray capsule header + the card under it, with animated arrow and expand/collapse. */
object Groups {

    /** Finds every view tagged "section" in the activity and makes it a collapsible header for the next card. */
    fun scan(act: Activity, prefs: SharedPreferences, key: String) {
        val collapse = prefs.getBoolean("groups_collapse", true)
        val open = (prefs.getString(key, "") ?: "").split(",").mapNotNull { it.toIntOrNull() }.toMutableSet()
        var n = 0
        fun walk(v: View) {
            if (v !is ViewGroup) return
            var i = 0
            while (i < v.childCount) {
                val c = v.getChildAt(i)
                if (c is TextView && c.tag == "section") {
                    var j = i + 1
                    while (j < v.childCount && v.getChildAt(j) !is MaterialCardView) j++
                    val card = v.getChildAt(j)
                    val idx = n++
                    if (card != null) {
                        style(c, true)
                        bind(c, card, idx in open, collapse) { isOpen ->
                            if (isOpen) open.add(idx) else open.remove(idx)
                            prefs.edit().putString(key, open.joinToString(",")).apply()
                        }
                    }
                } else walk(c)
                i++
            }
        }
        walk(act.findViewById(android.R.id.content))
    }

    fun style(tv: TextView, margins: Boolean) {
        val dm = tv.resources.displayMetrics.density
        val bg = MaterialColors.getColor(tv, com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3A3A3A.toInt())
        val fg = MaterialColors.getColor(tv, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFFB0B0B0.toInt())
        tv.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 100f * dm
            setColor(bg)
        }
        tv.setTextColor(fg)
        tv.setTypeface(Typeface.DEFAULT_BOLD)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        tv.gravity = Gravity.CENTER_VERTICAL
        tv.setPadding((22 * dm).toInt(), (14 * dm).toInt(), (16 * dm).toInt(), (14 * dm).toInt())
        if (margins) (tv.layoutParams as? ViewGroup.MarginLayoutParams)?.apply {
            marginStart = 0
            marginEnd = 0
            topMargin = (18 * dm).toInt()
            bottomMargin = (8 * dm).toInt()
        }
    }

    fun bind(header: TextView, target: View, startOpen: Boolean, collapse: Boolean, onToggle: (Boolean) -> Unit) {
        (target.getTag(R.id.tag_group_anim) as? ValueAnimator)?.cancel()
        target.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        (target.getTag(R.id.tag_group_base) as? Float)?.let { target.alpha = it }
        if (!collapse) {
            header.setCompoundDrawablesRelative(null, null, null, null)
            header.setOnClickListener(null)
            header.isClickable = false
            target.visibility = View.VISIBLE
            return
        }
        val dm = header.resources.displayMetrics.density
        val arrow = ArrowDrawable(header.currentTextColor, (32 * dm).toInt())
        arrow.setBounds(0, 0, arrow.intrinsicWidth, arrow.intrinsicHeight)
        arrow.progress = if (startOpen) 1f else 0f
        header.setCompoundDrawablesRelative(null, null, arrow, null)
        target.visibility = if (startOpen) View.VISIBLE else View.GONE
        var isOpen = startOpen
        header.setOnClickListener {
            isOpen = !isOpen
            onToggle(isOpen)
            animate(target, arrow, isOpen)
        }
    }

    private fun animate(target: View, arrow: ArrowDrawable, open: Boolean) {
        val running = target.getTag(R.id.tag_group_anim) as? ValueAnimator
        running?.cancel()
        // the resting alpha is remembered once, so a cancelled animation can never leave the card half-transparent
        val base = (target.getTag(R.id.tag_group_base) as? Float) ?: target.alpha.also { target.setTag(R.id.tag_group_base, it) }
        val lp = target.layoutParams
        val a0 = target.alpha
        val a1 = if (open) base else 0f
        val parent = target.parent as? View
        val from: Int
        val to: Int
        if (open) {
            from = if (target.visibility == View.VISIBLE) target.height else 0
            target.visibility = View.VISIBLE
            val w = (parent?.width ?: target.resources.displayMetrics.widthPixels) -
                ((lp as? ViewGroup.MarginLayoutParams)?.let { it.marginStart + it.marginEnd } ?: 0)
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            target.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            to = target.measuredHeight
        } else {
            from = target.height
            to = 0
        }
        val p0 = arrow.progress
        val p1 = if (open) 1f else 0f
        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                lp.height = (from + (to - from) * f).toInt()
                target.layoutParams = lp
                target.alpha = a0 + (a1 - a0) * f
                arrow.progress = p0 + (p1 - p0) * f
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    if (cancelled) return
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                    target.layoutParams = lp
                    target.alpha = base
                    target.visibility = if (open) View.VISIBLE else View.GONE
                    arrow.progress = p1
                }
            })
        }
        target.setTag(R.id.tag_group_anim, anim)
        anim.start()
    }
}
