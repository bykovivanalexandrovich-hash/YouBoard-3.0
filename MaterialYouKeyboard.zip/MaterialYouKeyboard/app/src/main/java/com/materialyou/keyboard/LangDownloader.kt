package com.materialyou.keyboard

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Downloads a word-frequency dictionary for one language into the app's private files. */
object LangDownloader {

    fun download(ctx: Context, d: Langs.Def, done: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        val h = Handler(Looper.getMainLooper())
        Thread {
            val ok = try {
                run(app, d)
            } catch (_: Throwable) {
                false
            }
            h.post { done(ok) }
        }.start()
    }

    private fun run(ctx: Context, d: Langs.Def): Boolean {
        val out = Langs.file(ctx, d)
        val code = d.dict
        if (code == null) {
            out.writeText("") // layout only
            return true
        }
        val words = LinkedHashSet<String>()
        for (name in listOf("${code}_50k.txt", "${code}_full.txt")) {
            try {
                val conn = URL("https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/$code/$name")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 20000
                conn.readTimeout = 40000
                if (conn.responseCode != 200) {
                    conn.disconnect()
                    continue
                }
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        val w = line.trim().substringBefore(' ').lowercase().replace('\u2019', '\'').replace('\u02BC', '\'')
                        if (w.isEmpty() || w.startsWith("'") || w.endsWith("'") || w.length > 24) continue
                        if (w.length == 1 && w !in d.singles) continue
                        if (!w.all { it in d.letters }) continue
                        words.add(w)
                        if (words.size >= 50000) break
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
            }
            if (words.size > 500) break
        }
        if (words.size <= 500) return false
        val tmp = File(out.path + ".tmp")
        tmp.writeText(words.joinToString("\n"))
        if (out.exists()) out.delete()
        return tmp.renameTo(out)
    }
}
