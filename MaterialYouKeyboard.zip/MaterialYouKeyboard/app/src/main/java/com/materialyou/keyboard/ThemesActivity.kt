package com.materialyou.keyboard

import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.color.MaterialColors

/** Keyboard themes and background gradient effects. */
class ThemesActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private var barCtl: BottomBar.Controller? = null
    private val repaint = ArrayList<() -> Unit>()
    private var d = 1f

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        barCtl?.feed(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun attr(a: Int, fb: Int) = MaterialColors.getColor(this, a, fb)
    private fun dp(v: Int) = (v * d).toInt()
    private fun isDark() = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

    /** bg, letter, function, primary of the theme as the keyboard shows it */
    private fun win95() = prefs.getBoolean("win95", false)

    private fun pal(id0: String): IntArray {
        val id = if (win95()) Themes.WIN95 else id0
        Themes.colors(id, isDark())?.let { return intArrayOf(it.bg, it.letter, it.function, it.primary) }
        return intArrayOf(
            attr(com.google.android.material.R.attr.colorSurfaceContainer, 0xFF2B2930.toInt()),
            attr(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF36343B.toInt()),
            attr(com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt()),
            attr(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt())
        )
    }

    private fun curTheme() = prefs.getString(Themes.KEY, "system") ?: "system"
    private fun curFx() = if (win95()) "none" else prefs.getString(Fx.KEY, "none") ?: "none"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_themes)
        d = resources.displayMetrics.density
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !isDark()
        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        findViewById<MaterialToolbar>(R.id.th_toolbar).setNavigationOnClickListener { finish() }

        setupPreview()
        setupThemes()
        setupFx()
        plus = PlusCard(this, prefs).also { it.setup() }
        setupBg()
        findViewById<View>(R.id.btn_key_editor).setOnClickListener {
            startActivity(android.content.Intent(this, KeyEditorActivity::class.java))
        }
        if (win95()) for (id in listOf(R.id.theme_card, R.id.fx_card)) findViewById<View>(id).alpha = 0.4f
        Groups.scan(this, prefs, "groups_open_themes")
        barCtl = BottomBar.attach(this, BottomBar.THEMES)
    }

    private var plus: PlusCard? = null
    private var importing = false
    private val pickPhoto = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            importing = true
            setupBg()
            Thread {
                val f = BgPhotos.add(this, uri)
                runOnUiThread {
                    importing = false
                    if (f != null) {
                        prefs.edit().putString(BgPhotos.SEL, f.name).putBoolean(BgPhotos.ON, true).apply()
                    } else {
                        android.widget.Toast.makeText(this, R.string.bg_fail, android.widget.Toast.LENGTH_SHORT).show()
                    }
                    setupBg()
                }
            }.start()
        }
    }

    override fun onResume() {
        super.onResume()
        plus?.sync()
        plus?.repaint()
    }

    /** Keyboard background from the user's own photos: a switch and a row of 9:16 tiles starting with a "+". */
    private fun setupBg() {
        val box = findViewById<LinearLayout>(R.id.bg_box)
        box.removeAllViews()
        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val muted = attr(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF938F99.toInt())
        val primary = attr(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt())
        val high = attr(com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E.toInt())

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((20 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), 0)
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(TextView(this).apply {
            text = getString(R.string.sw_bg)
            textSize = 16f
            setTextColor(onSurface)
        })
        titles.addView(TextView(this).apply {
            text = getString(R.string.bg_hint)
            textSize = 12f
            setTextColor(muted)
        })
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = com.google.android.material.materialswitch.MaterialSwitch(this).apply {
            isSaveEnabled = false
            isChecked = prefs.getBoolean(BgPhotos.ON, false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(BgPhotos.ON, on).apply() }
        }
        head.addView(sw)
        box.addView(head)

        val scroll = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((16 * d).toInt(), (14 * d).toInt(), (16 * d).toInt(), (4 * d).toInt())
        }
        scroll.addView(row)
        box.addView(scroll)

        val w = (90 * d).toInt()
        val h = w * 16 / 9
        val sel = prefs.getString(BgPhotos.SEL, null)

        // "+" tile
        val add = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18 * d
                setColor(high)
            }
            isClickable = true
            setOnClickListener { pickPhoto.launch("image/*") }
        }
        if (importing) {
            add.addView(WavyProgressView(this), FrameLayout.LayoutParams((44 * d).toInt(), (44 * d).toInt(), Gravity.CENTER))
        } else {
            add.addView(TextView(this).apply {
                text = "+"
                textSize = 40f
                gravity = Gravity.CENTER
                setTextColor(primary)
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        row.addView(add, LinearLayout.LayoutParams(w, h).apply { marginEnd = (10 * d).toInt() })

        for (file in BgPhotos.list(this)) {
            val tile = FrameLayout(this).apply {
                val on = file.name == sel
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 18 * d
                    setColor(0x00000000)
                    if (on) setStroke((3 * d).toInt(), primary)
                }
                setPadding((3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt())
            }
            val iv = android.widget.ImageView(this).apply {
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                setImageBitmap(BgPhotos.thumb(file))
                clipToOutline = true
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(v: View, o: android.graphics.Outline) {
                        o.setRoundRect(0, 0, v.width, v.height, 15 * d)
                    }
                }
            }
            tile.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            tile.setOnClickListener {
                prefs.edit().putString(BgPhotos.SEL, file.name).putBoolean(BgPhotos.ON, true).apply()
                setupBg()
            }
            tile.setOnLongClickListener {
                com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.bg_delete_title)
                    .setNegativeButton(R.string.cancel, null)
                    .setPositiveButton(R.string.lang_delete_ok) { _, _ ->
                        file.delete()
                        if (prefs.getString(BgPhotos.SEL, null) == file.name) prefs.edit().remove(BgPhotos.SEL).apply()
                        setupBg()
                    }
                    .show()
                true
            }
            row.addView(tile, LinearLayout.LayoutParams(w, h).apply { marginEnd = (10 * d).toInt() })
        }
    }

    private fun setupPreview() {
        val box = findViewById<LinearLayout>(R.id.th_preview)
        val keys = ArrayList<Pair<View, Int>>() // view, colour index (1 letter, 2 function, 3 primary)
        fun row(spec: List<Int>) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in spec) {
                val v = View(this)
                keys.add(v to k)
                r.addView(v, LinearLayout.LayoutParams(0, dp(30), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            box.addView(r)
        }
        row(listOf(1, 1, 1, 1, 1, 1, 1))
        row(listOf(1, 1, 1, 1, 1, 1, 1))
        row(listOf(2, 1, 1, 1, 1, 1, 3))
        row(listOf(2, 1, 1, 1, 1, 1, 3))
        val paint = {
            val p = pal(curTheme())
            box.background = Fx.drawable(curFx(), p[0], p[3], fxX() / 100f, fxY() / 100f, fxSize() / 100f)
            for ((v, k) in keys) v.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(14).toFloat()
                setColor(p[k])
            }
        }
        paint()
        repaint.add(paint)
    }

    private fun migrateLegacy() {
        // the old fixed colour themes become ordinary user colours
        val cur = curTheme()
        if (cur in listOf("purple", "green", "blue", "orange", "red")) {
            val s = Themes.seed(cur) ?: return
            Themes.addCustom(prefs, s)
            prefs.edit().putString(Themes.KEY, Themes.idOf(s)).apply()
        }
    }

    private fun chooseTheme(id: String) {
        if (id == curTheme()) return
        prefs.edit().putString(Themes.KEY, id).apply()
        App.colorsChanged()
        recreate()
    }

    private fun setupThemes() {
        migrateLegacy()
        val row = findViewById<LinearLayout>(R.id.theme_row)
        row.removeAllViews()
        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val outline = attr(com.google.android.material.R.attr.colorOutline, 0xFF938F99.toInt())
        val sysColor = if (android.os.Build.VERSION.SDK_INT >= 31) getColor(android.R.color.system_accent1_500)
        else attr(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt())
        val cur = curTheme()

        fun addCell(id: String?, color: Int, text: String, plus: Boolean) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                isFocusable = true
            }
            val frame = FrameLayout(this)
            val sw = TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 22f
                setTextColor(onSurface)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    if (plus) setStroke(dp(1), outline) else setColor(color)
                }
                if (plus) this.text = "+"
            }
            frame.addView(sw, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
            val on = id != null && id == cur
            val ring = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0x00000000)
                    if (!plus) setStroke(dp(if (on) 3 else 1), if (on) onSurface else outline)
                }
            }
            if (!plus) frame.addView(ring, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))
            cell.addView(frame, LinearLayout.LayoutParams(dp(52), dp(52)))
            val label = TextView(this).apply {
                this.text = text
                textSize = 10f
                gravity = Gravity.CENTER
                maxLines = 1
                setTextColor(onSurface)
                alpha = if (on || plus) 1f else 0.7f
            }
            cell.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            cell.setOnClickListener {
                if (win95()) return@setOnClickListener
                if (plus) pickColor() else chooseTheme(id ?: "system")
            }
            if (id != null && id.startsWith("c:")) {
                cell.setOnLongClickListener {
                    MaterialAlertDialogBuilder(this)
                        .setMessage(R.string.th_del_q)
                        .setNegativeButton(R.string.ke_no, null)
                        .setPositiveButton(R.string.th_del) { _, _ ->
                            Themes.removeCustom(prefs, Themes.seed(id) ?: 0)
                            if (curTheme() == id) {
                                prefs.edit().putString(Themes.KEY, "system").apply()
                                App.colorsChanged()
                                recreate()
                            } else setupThemes()
                        }
                        .show()
                    true
                }
            }
            row.addView(cell, LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        addCell("system", sysColor, getString(R.string.theme_system), false)
        for (c in Themes.customs(prefs)) addCell(Themes.idOf(c), c, "#%06X".format(c and 0xFFFFFF), false)
        addCell(null, 0, getString(R.string.th_add), true)
    }

    /** Palette: ready colours plus hue / saturation / brightness; the chosen colour is added to the list. */
    private fun pickColor() {
        val hsv = floatArrayOf(260f, 0.6f, 0.9f)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(4))
        }
        val prev = View(this)
        box.addView(prev, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
        fun upd() {
            prev.background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(android.graphics.Color.HSVToColor(hsv))
            }
        }
        val sliders = ArrayList<com.google.android.material.slider.Slider>()
        fun sl(label: Int, from: Float, to: Float, idx: Int, scale: Float): com.google.android.material.slider.Slider {
            box.addView(TextView(this).apply {
                text = getString(label)
                textSize = 13f
                setTextColor(attr(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF938F99.toInt()))
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
            val s = com.google.android.material.slider.Slider(this).apply {
                valueFrom = from
                valueTo = to
                value = (hsv[idx] * scale).coerceIn(from, to)
                isSaveEnabled = false
                addOnChangeListener { _, v, _ ->
                    hsv[idx] = v / scale
                    upd()
                }
            }
            box.addView(s)
            sliders.add(s)
            return s
        }
        val presets = intArrayOf(
            0xFFE53935.toInt(), 0xFFD81B60.toInt(), 0xFF8E24AA.toInt(), 0xFF5E35B1.toInt(), 0xFF3949AB.toInt(),
            0xFF1E88E5.toInt(), 0xFF039BE5.toInt(), 0xFF00ACC1.toInt(), 0xFF00897B.toInt(), 0xFF43A047.toInt(),
            0xFF7CB342.toInt(), 0xFFFDD835.toInt(), 0xFFFB8C00.toInt(), 0xFF6D4C41.toInt()
        )
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (chunk in presets.toList().chunked(7)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in chunk) {
                val dot = View(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(c)
                    }
                    setOnClickListener {
                        android.graphics.Color.colorToHSV(c, hsv)
                        sliders.getOrNull(0)?.value = hsv[0].coerceIn(0f, 360f)
                        sliders.getOrNull(1)?.value = (hsv[1] * 100f).coerceIn(0f, 100f)
                        sliders.getOrNull(2)?.value = (hsv[2] * 100f).coerceIn(20f, 100f)
                        upd()
                    }
                }
                r.addView(dot, LinearLayout.LayoutParams(0, dp(34), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            grid.addView(r)
        }
        box.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        sl(R.string.th_hue, 0f, 360f, 0, 1f)
        sl(R.string.th_sat, 0f, 100f, 1, 100f)
        sl(R.string.th_val, 20f, 100f, 2, 100f)
        upd()
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.th_pick)
            .setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton(R.string.ke_no, null)
            .setPositiveButton(R.string.th_add) { _, _ ->
                val color = android.graphics.Color.HSVToColor(hsv)
                Themes.addCustom(prefs, color)
                prefs.edit().putString(Themes.KEY, Themes.idOf(color)).apply()
                App.colorsChanged()
                recreate()
            }
            .show()
    }

    private fun fxX() = prefs.getInt("fx_x", 50)
    private fun fxY() = prefs.getInt("fx_y", 30)
    private fun fxSize() = prefs.getInt("fx_size", 70)

    private fun setupFx() {
        val grid = findViewById<LinearLayout>(R.id.fx_grid)
        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val outline = attr(com.google.android.material.R.attr.colorOutline, 0xFF938F99.toInt())
        val names = mapOf(
            "down" to R.string.fx_down, "up" to R.string.fx_up, "glow" to R.string.fx_glow, "diag" to R.string.fx_diag,
            "free" to R.string.fx_free
        )
        // the free glow: drag over the preview to move it, the slider changes its size
        val glowBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val pad = GlowPad(this)
        glowBox.addView(TextView(this).apply {
            text = getString(R.string.fx_free_hint)
            textSize = 13f
            setTextColor(attr(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF938F99.toInt()))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(4)
            bottomMargin = dp(8)
        })
        glowBox.addView(pad, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)))
        val sizeSlider = com.google.android.material.slider.Slider(this).apply {
            valueFrom = 30f
            valueTo = 120f
            stepSize = 5f
            value = fxSize().toFloat().coerceIn(30f, 120f)
            isSaveEnabled = false
            addOnChangeListener { _, v, fromUser ->
                if (fromUser) {
                    prefs.edit().putInt("fx_size", v.toInt()).apply()
                    pad.size = v / 100f
                    pad.invalidate()
                    repaint.forEach { it() }
                }
            }
        }
        glowBox.addView(TextView(this).apply {
            text = getString(R.string.fx_free_size)
            textSize = 13f
            setTextColor(onSurface)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        glowBox.addView(sizeSlider)
        pad.onDone = { x, y ->
            prefs.edit().putInt("fx_x", (x * 100).toInt()).putInt("fx_y", (y * 100).toInt()).apply()
            repaint.forEach { it() }
        }
        val tiles = ArrayList<Pair<String, View>>()
        fun paint() {
            val p = pal(curTheme())
            val cur = curFx()
            for ((id, v) in tiles) {
                val g = Fx.drawable(id, p[0], p[3], fxX() / 100f, fxY() / 100f, fxSize() / 100f)
                val sw = dp(if (id == cur) 3 else 1)
                val sc = if (id == cur) onSurface else outline
                if (g is GradientDrawable) {
                    g.cornerRadius = dp(18).toFloat()
                    g.setStroke(sw, sc)
                } else if (g is GlowDrawable) {
                    g.round = dp(18).toFloat()
                    g.strokeW = sw.toFloat()
                    g.strokeColor = sc
                }
                v.background = g
            }
            pad.bg = p[0]
            pad.accent = p[3]
            pad.ring = onSurface
            pad.gx = fxX() / 100f
            pad.gy = fxY() / 100f
            pad.size = fxSize() / 100f
            pad.invalidate()
            glowBox.visibility = if (cur == "free" && !win95()) View.VISIBLE else View.GONE
        }
        for (pair in Fx.IDS.chunked(2)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (id in pair) {
                val cell = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    isClickable = true
                    isFocusable = true
                }
                val tile = View(this)
                cell.addView(tile, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72)))
                val label = TextView(this).apply {
                    text = getString(names.getValue(id))
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTextColor(onSurface)
                }
                cell.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
                cell.setOnClickListener {
                    if (win95()) return@setOnClickListener
                    // tapping the chosen effect again turns it off
                    prefs.edit().putString(Fx.KEY, if (curFx() == id) "none" else id).apply()
                    repaint.forEach { it() }
                }
                tiles.add(id to tile)
                r.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(8)) })
            }
            grid.addView(r)
        }
        grid.addView(glowBox)
        paint()
        repaint.add { paint() }
    }
}
