package com.materialyou.keyboard

import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.color.MaterialColors

/** Keyboard themes and background gradient effects. */
class ThemesActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private var barCtl: BottomBar.Controller? = null
    private val repaint = ArrayList<() -> Unit>()
    private var d = 1f

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        barCtl?.feed(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun attr(a: Int, fb: Int) = MaterialColors.getColor(this, a, fb)
    private fun dp(v: Int) = (v * d).toInt()
    private fun isDark() = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

    /** bg, letter, function, primary of the theme as the keyboard shows it */
    private fun win95() = prefs.getBoolean("win95", false)

    private fun pal(id0: String): IntArray {
        val id = if (win95()) Themes.WIN95 else id0
        Themes.colors(id, isDark())?.let { return intArrayOf(it.bg, it.letter, it.function, it.primary) }
        return intArrayOf(
            attr(com.google.android.material.R.attr.colorSurfaceContainer, 0xFF2B2930.toInt()),
            attr(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF36343B.toInt()),
            attr(com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt()),
            attr(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt())
        )
    }

    private fun curTheme() = prefs.getString(Themes.KEY, "system") ?: "system"
    private fun curFx() = if (win95()) "none" else prefs.getString(Fx.KEY, "none") ?: "none"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_themes)
        d = resources.displayMetrics.density
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !isDark()
        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        findViewById<MaterialToolbar>(R.id.th_toolbar).setNavigationOnClickListener { finish() }

        setupPreview()
        setupThemes()
        setupFx()
        if (win95()) for (id in listOf(R.id.theme_card, R.id.fx_card)) findViewById<View>(id).alpha = 0.4f
        barCtl = BottomBar.attach(this, BottomBar.THEMES)
    }

    private fun setupPreview() {
        val box = findViewById<LinearLayout>(R.id.th_preview)
        val keys = ArrayList<Pair<View, Int>>() // view, colour index (1 letter, 2 function, 3 primary)
        fun row(spec: List<Int>) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in spec) {
                val v = View(this)
                keys.add(v to k)
                r.addView(v, LinearLayout.LayoutParams(0, dp(30), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            box.addView(r)
        }
        row(listOf(1, 1, 1, 1, 1, 1, 1))
        row(listOf(1, 1, 1, 1, 1, 1, 1))
        row(listOf(2, 1, 1, 1, 1, 1, 3))
        row(listOf(2, 1, 1, 1, 1, 1, 3))
        val paint = {
            val p = pal(curTheme())
            box.background = Fx.drawable(curFx(), p[0], p[3])
            for ((v, k) in keys) v.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(14).toFloat()
                setColor(p[k])
            }
        }
        paint()
        repaint.add(paint)
    }

    private fun setupThemes() {
        val row = findViewById<LinearLayout>(R.id.theme_row)
        val names = mapOf(
            "system" to R.string.theme_system, "purple" to R.string.theme_purple, "green" to R.string.theme_green,
            "blue" to R.string.theme_blue, "orange" to R.string.theme_orange
        )
        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val outline = attr(com.google.android.material.R.attr.colorOutline, 0xFF938F99.toInt())
        val cells = ArrayList<Triple<String, View, TextView>>()
        fun refresh() {
            val cur = curTheme()
            for ((id, ring, label) in cells) {
                val on = id == cur
                (ring.background as GradientDrawable).setStroke(dp(if (on) 3 else 1), if (on) onSurface else outline)
                label.setTextColor(onSurface)
                label.alpha = if (on) 1f else 0.7f
            }
        }
        for (id in Themes.IDS) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                isFocusable = true
            }
            val swatchColor = if (id == "system") attr(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt()) else Themes.swatch(id)
            val sw = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(swatchColor)
                }
            }
            val frame = FrameLayout(this)
            frame.addView(sw, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
            val ring = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0x00000000)
                }
            }
            frame.addView(ring, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))
            cell.addView(frame, LinearLayout.LayoutParams(dp(52), dp(52)))
            val label = TextView(this).apply {
                text = getString(names.getValue(id))
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
            }
            cell.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            cell.setOnClickListener {
                if (win95()) return@setOnClickListener
                prefs.edit().putString(Themes.KEY, id).apply()
                refresh()
                repaint.forEach { it() }
            }
            row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            cells.add(Triple(id, ring, label))
        }
        refresh()
    }

    private fun setupFx() {
        val grid = findViewById<LinearLayout>(R.id.fx_grid)
        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val outline = attr(com.google.android.material.R.attr.colorOutline, 0xFF938F99.toInt())
        val names = mapOf(
            "down" to R.string.fx_down, "up" to R.string.fx_up, "glow" to R.string.fx_glow, "diag" to R.string.fx_diag
        )
        val tiles = ArrayList<Pair<String, View>>()
        fun paint() {
            val p = pal(curTheme())
            val cur = curFx()
            for ((id, v) in tiles) {
                val g = Fx.drawable(id, p[0], p[3]) as GradientDrawable
                g.cornerRadius = dp(18).toFloat()
                g.setStroke(dp(if (id == cur) 3 else 1), if (id == cur) onSurface else outline)
                v.background = g
            }
        }
        for (pair in Fx.IDS.chunked(2)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (id in pair) {
                val cell = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    isClickable = true
                    isFocusable = true
                }
                val tile = View(this)
                cell.addView(tile, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72)))
                val label = TextView(this).apply {
                    text = getString(names.getValue(id))
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTextColor(onSurface)
                }
                cell.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
                cell.setOnClickListener {
                    if (win95()) return@setOnClickListener
                    // tapping the chosen effect again turns it off
                    prefs.edit().putString(Fx.KEY, if (curFx() == id) "none" else id).apply()
                    repaint.forEach { it() }
                }
                tiles.add(id to tile)
                r.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(8)) })
            }
            grid.addView(r)
        }
        paint()
        repaint.add { paint() }
    }
}
