package com.materialyou.keyboard

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Resources
import java.io.File

/** Catalog of the 25 keyboard languages: layouts, long-press letters and where their dictionaries come from. */
object Langs {

    class Def(
        val code: String,
        val title: String,
        val ru: String,
        val en: String,
        val rows: List<String>,
        val alts: Map<String, String> = emptyMap(),
        val dict: String?,            // FrequencyWords code, null = no dictionary (layout only)
        val builtin: Boolean = false,
        val asset: String? = null,
        val singles: String = ""      // one-letter words that are real words
    ) {
        /** Every character a word of this language may contain. */
        val letters: Set<Char> by lazy { (rows.joinToString("") + alts.values.joinToString("")).toSet() + '\'' }
    }

    private val QWERTY = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val QWERTZ = listOf("qwertzuiop", "asdfghjkl", "yxcvbnm")

    val RU = Def("RU", "Русский", "Русский", "Russian", Layouts.RU_ROWS, emptyMap(), "ru", true, "dict_ru.txt")
    val UK = Def("UK", "Українська", "Украинский", "Ukrainian", Layouts.UK_ROWS, emptyMap(), "uk", true, "dict_uk.txt")
    val EN = Def("EN", "English", "Английский", "English", Layouts.EN_ROWS, emptyMap(), "en", true, "dict_en.txt")

    val all: List<Def> = listOf(
        RU, UK, EN,
        Def("BE", "Беларуская", "Белорусский", "Belarusian", listOf("йцукенгшўзх", "фывапролджэ", "ячсмітьбю"),
            mapOf("е" to "ё", "ь" to "\'"), null),
        Def("PL", "Polski", "Польский", "Polish", QWERTY,
            mapOf("a" to "ą", "c" to "ć", "e" to "ę", "l" to "ł", "n" to "ń", "o" to "ó", "s" to "ś", "z" to "źż"), "pl", singles = "aiouwz"),
        Def("DE", "Deutsch", "Немецкий", "German", listOf("qwertzuiopü", "asdfghjklöä", "yxcvbnmß"), emptyMap(), "de"),
        Def("FR", "Français", "Французский", "French", listOf("azertyuiop", "qsdfghjklm", "wxcvbn"),
            mapOf("a" to "àâæ", "e" to "éèêë", "i" to "îï", "o" to "ôœ", "u" to "ùûü", "c" to "ç", "y" to "ÿ"), "fr", singles = "aàyoux"),
        Def("ES", "Español", "Испанский", "Spanish", listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm"),
            mapOf("a" to "á", "e" to "é", "i" to "í", "o" to "ó", "u" to "úü"), "es", singles = "aoyeu"),
        Def("IT", "Italiano", "Итальянский", "Italian", QWERTY,
            mapOf("a" to "à", "e" to "èé", "i" to "ì", "o" to "òó", "u" to "ù"), "it", singles = "aeio"),
        Def("PT", "Português", "Португальский", "Portuguese", QWERTY,
            mapOf("a" to "áàâã", "e" to "éê", "i" to "í", "o" to "óôõ", "u" to "ú", "c" to "ç"), "pt", singles = "aeo"),
        Def("TR", "Türkçe", "Турецкий", "Turkish", listOf("qwertyuıopğü", "asdfghjklşi", "zxcvbnmöç"), emptyMap(), "tr", singles = "o"),
        Def("CS", "Čeština", "Чешский", "Czech", QWERTZ,
            mapOf("a" to "á", "c" to "č", "d" to "ď", "e" to "éě", "i" to "í", "n" to "ň", "o" to "ó", "r" to "ř", "s" to "š",
                "t" to "ť", "u" to "úů", "y" to "ý", "z" to "ž"), "cs", singles = "aikosuvz"),
        Def("SK", "Slovenčina", "Словацкий", "Slovak", QWERTZ,
            mapOf("a" to "áä", "c" to "č", "d" to "ď", "e" to "é", "i" to "í", "l" to "ĺľ", "n" to "ň", "o" to "óô", "r" to "ŕ",
                "s" to "š", "t" to "ť", "u" to "ú", "y" to "ý", "z" to "ž"), "sk", singles = "aikosuvz"),
        Def("NL", "Nederlands", "Нидерландский", "Dutch", QWERTY,
            mapOf("a" to "áä", "e" to "éë", "i" to "íï", "o" to "óö", "u" to "úü"), "nl", singles = "u"),
        Def("SV", "Svenska", "Шведский", "Swedish", listOf("qwertyuiopå", "asdfghjklöä", "zxcvbnm"),
            mapOf("e" to "é"), "sv", singles = "iåa"),
        Def("DA", "Dansk", "Датский", "Danish", listOf("qwertyuiopå", "asdfghjklæø", "zxcvbnm"),
            mapOf("e" to "é"), "da", singles = "iåa"),
        Def("FI", "Suomi", "Финский", "Finnish", listOf("qwertyuiopå", "asdfghjklöä", "zxcvbnm"), emptyMap(), "fi"),
        Def("RO", "Română", "Румынский", "Romanian", QWERTY,
            mapOf("a" to "ăâ", "i" to "î", "s" to "ș", "t" to "ț"), "ro", singles = "a"),
        Def("HU", "Magyar", "Венгерский", "Hungarian", listOf("qwertzuiopőú", "asdfghjkléá", "yxcvbnmöüó"),
            mapOf("i" to "í", "u" to "ű"), "hu", singles = "as"),
        Def("BG", "Български", "Болгарский", "Bulgarian", listOf("явертъуиопчш", "асдфгхйклщ", "зьцжбнмю"), emptyMap(), "bg", singles = "авеикосуя"),
        Def("EL", "Ελληνικά", "Греческий", "Greek", listOf("ερτυθιοπ", "ασδφγηξκλ", "ζχψωβνμ"),
            mapOf("α" to "ά", "ε" to "έ", "η" to "ή", "ι" to "ίϊ", "ο" to "ό", "υ" to "ύϋ", "ω" to "ώ", "σ" to "ς"), "el", singles = "ηοωτσκ"),
        Def("SR", "Српски", "Сербский", "Serbian", listOf("љњертзуиопш", "асдфгхјклчћ", "џцвбнмжђ"), emptyMap(), "sr", singles = "иоуакс"),
        Def("HR", "Hrvatski", "Хорватский", "Croatian", listOf("qwertzuiopšđ", "asdfghjklčć", "yxcvbnmž"), emptyMap(), "hr", singles = "aiosuk"),
        Def("KK", "Қазақша", "Казахский", "Kazakh", listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю"),
            mapOf("а" to "ә", "г" to "ғ", "к" to "қ", "н" to "ң", "о" to "ө", "у" to "ұү", "х" to "һ", "и" to "і"), "kk"),
        Def("LT", "Lietuvių", "Литовский", "Lithuanian", QWERTY,
            mapOf("a" to "ą", "c" to "č", "e" to "ęė", "i" to "į", "s" to "š", "u" to "ųū", "z" to "ž"), "lt", singles = "aiouč")
    )

    val byCode: Map<String, Def> = all.associateBy { it.code }

    fun file(ctx: Context, d: Def) = File(ctx.filesDir, "dict_${d.code}.txt")

    fun installed(ctx: Context, d: Def) = d.builtin || file(ctx, d).exists()

    /** Old "kb_langs" setting, used until the language list is touched for the first time. */
    private fun legacy(p: SharedPreferences): List<String> {
        val second = when (p.getString("kb_langs", "auto")) {
            "ru" -> listOf("RU")
            "uk" -> listOf("UK")
            "ru_uk" -> listOf("RU", "UK")
            else -> if (Resources.getSystem().configuration.locales.get(0)?.language == "uk") listOf("UK") else listOf("RU")
        }
        return second + "EN"
    }

    fun enabledCodes(p: SharedPreferences): Set<String> {
        val raw = p.getString("langs_on", null)
        return (if (raw != null) raw.split(",").filter { it.isNotEmpty() } else legacy(p)).toSet()
    }

    /** Languages in switching order (the catalog order): enabled and downloaded ones. */
    fun enabled(ctx: Context, p: SharedPreferences): List<Def> {
        val codes = enabledCodes(p)
        val list = all.filter { it.code in codes && installed(ctx, it) }
        return if (list.isEmpty()) listOf(EN) else list
    }

    fun setEnabled(p: SharedPreferences, codes: Set<String>) {
        p.edit().putString("langs_on", all.map { it.code }.filter { it in codes }.joinToString(",")).apply()
    }
}
