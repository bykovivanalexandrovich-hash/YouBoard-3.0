package com.materialyou.keyboard

import android.animation.ValueAnimator
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private class PreviewKey(
        val view: TextView, val kind: KeyKind, val d: GradientDrawable, val cur: FloatArray,
        val bgI: Int, val fgI: Int
    )

    private lateinit var prefs: SharedPreferences
    private lateinit var imm: InputMethodManager
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var step1: TextView
    private lateinit var step2: TextView
    private lateinit var btnAction: MaterialButton
    private val previewKeys = ArrayList<PreviewKey>()
    private var previewH = 0f
    private var autoRow: View? = null
    private var joyRow: View? = null
    private var bottomBar: View? = null
    private var refreshLangRow: (() -> Unit)? = null
    private var dynamicColors = IntArray(8)
    private var swPlus: MaterialSwitch? = null
    private var langRow: LinearLayout? = null

    private fun isDark(): Boolean =
        (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES

    /** letter, onSurface, function, onFunction, tertiary, onTertiary, primary, onPrimary */
    private fun previewColors(): IntArray {
        val t = Themes.colors(prefs.getString(Themes.KEY, "system") ?: "system", isDark()) ?: return dynamicColors
        return intArrayOf(t.space, t.onSurface, t.function, t.onFunction, t.tertiary, t.onTertiary, t.primary, t.onPrimary)
    }

    private fun repaintPreview() {
        val cols = previewColors()
        for (k in previewKeys) {
            k.d.setColor(cols[k.bgI])
            k.view.setTextColor(cols[k.fgI])
        }
    }

    private fun setupLangSwitch() {
        val row = findViewById<LinearLayout>(R.id.langswitch_row)
        langRow = row
        val density = resources.displayMetrics.density
        val bg = color(row, com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt())
        val fg = color(row, com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt())
        val onSurface = color(row, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val outline = color(row, com.google.android.material.R.attr.colorOutline, 0xFF938F99.toInt())
        val items = listOf(
            Triple("menu", R.drawable.ic_menu, R.string.ls_menu),
            Triple("globe", R.drawable.ic_globe, R.string.ls_globe),
            Triple("swipe", R.drawable.ic_swipe, R.string.ls_swipe)
        )
        val cells = ArrayList<Triple<String, View, TextView>>()
        fun refresh() {
            val cur = LangSwitch.mode(prefs)
            val joyOn = prefs.getBoolean("space_joystick", false)
            for ((id, ring, label) in cells) {
                val on = id == cur
                (ring.background as GradientDrawable).setStroke(
                    ((if (on) 3 else 1) * density).toInt(), if (on) onSurface else outline
                )
                label.alpha = if (on) 1f else 0.7f
                if (id == "swipe" && joyOn) {
                    (ring.parent as? View)?.parent?.let { (it as View).alpha = 0.35f }
                    label.alpha = 0.35f
                } else (ring.parent as? View)?.parent?.let { (it as View).alpha = 1f }
            }
            updateJoyRow()
        }
        for ((id, icon, name) in items) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                isFocusable = true
            }
            val frame = android.widget.FrameLayout(this)
            val disc = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(bg)
                }
            }
            frame.addView(disc, android.widget.FrameLayout.LayoutParams((40 * density).toInt(), (40 * density).toInt(), Gravity.CENTER))
            val iv = android.widget.ImageView(this).apply {
                setImageResource(icon)
                setColorFilter(fg)
            }
            frame.addView(iv, android.widget.FrameLayout.LayoutParams((22 * density).toInt(), (22 * density).toInt(), Gravity.CENTER))
            val ring = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0x00000000)
                }
            }
            frame.addView(ring, android.widget.FrameLayout.LayoutParams((48 * density).toInt(), (48 * density).toInt(), Gravity.CENTER))
            cell.addView(frame, LinearLayout.LayoutParams((52 * density).toInt(), (52 * density).toInt()))
            val label = TextView(this).apply {
                text = getString(name)
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
                setTextColor(onSurface)
            }
            cell.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            cell.setOnClickListener {
                if (prefs.getBoolean("lang_switch_all", false)) return@setOnClickListener
                if (id == "swipe" && prefs.getBoolean("space_joystick", false)) return@setOnClickListener
                prefs.edit().putString(LangSwitch.KEY, id).apply()
                refresh()
            }
            row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            cells.add(Triple(id, ring, label))
        }
        refresh()
        refreshLangRow = { refresh() }
    }

    private fun setupTheme() {
        val row = findViewById<LinearLayout>(R.id.theme_row)
        val density = resources.displayMetrics.density
        val names = mapOf(
            "system" to R.string.theme_system, "purple" to R.string.theme_purple, "green" to R.string.theme_green,
            "blue" to R.string.theme_blue, "orange" to R.string.theme_orange
        )
        val onSurface = color(row, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val outline = color(row, com.google.android.material.R.attr.colorOutline, 0xFF938F99.toInt())
        val cells = ArrayList<Triple<String, View, TextView>>()
        fun refresh() {
            val cur = prefs.getString(Themes.KEY, "system") ?: "system"
            for ((id, ring, label) in cells) {
                val on = id == cur
                (ring.background as GradientDrawable).setStroke(
                    ((if (on) 3 else 1) * density).toInt(), if (on) onSurface else outline
                )
                label.setTextColor(onSurface)
                label.alpha = if (on) 1f else 0.7f
            }
        }
        for (id in Themes.IDS) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                isFocusable = true
            }
            val swatchColor = if (id == "system") dynamicColors[6] else Themes.swatch(id)
            val sw = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(swatchColor)
                }
            }
            // system option: half the circle uses the secondary-container colour to hint at "wallpaper colours"
            val ringBg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x00000000)
            }
            val frame = android.widget.FrameLayout(this)
            frame.addView(sw, android.widget.FrameLayout.LayoutParams((40 * density).toInt(), (40 * density).toInt(), Gravity.CENTER))
            val ring = View(this).apply { background = ringBg }
            frame.addView(ring, android.widget.FrameLayout.LayoutParams((48 * density).toInt(), (48 * density).toInt(), Gravity.CENTER))
            cell.addView(frame, LinearLayout.LayoutParams((52 * density).toInt(), (52 * density).toInt()))
            val label = TextView(this).apply {
                text = getString(names.getValue(id))
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
            }
            cell.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            cell.setOnClickListener {
                prefs.edit().putString(Themes.KEY, id).apply()
                refresh()
                repaintPreview()
            }
            row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            cells.add(Triple(id, ring, label))
        }
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // status bar icons follow the theme: dark icons on a light bar, light icons on a dark bar
        androidx.core.view.WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
            (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) !=
                    android.content.res.Configuration.UI_MODE_NIGHT_YES

        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        imm = getSystemService(InputMethodManager::class.java)

        heroTitle = findViewById(R.id.hero_title)
        heroSub = findViewById(R.id.hero_sub)
        step1 = findViewById(R.id.step1)
        step2 = findViewById(R.id.step2)
        btnAction = findViewById(R.id.btn_action)
        btnAction.setOnClickListener {
            if (!isEnabled()) {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            } else if (!isDefault()) {
                imm.showInputMethodPicker()
            }
        }

        bottomBar = BottomBar.attach(this, BottomBar.SETTINGS)

        setupPlus()
        setupTheme()
        setupLangSwitch()
        setupRows()
        setupHeight()

        findViewById<View>(R.id.btn_clear_clips).setOnClickListener {
            ClipStore(prefs).clearAll()
            com.google.android.material.snackbar.Snackbar
                .make(it, getString(R.string.clips_cleared), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        syncSquare()
        // the hidden "all methods at once" switch makes the single-choice row irrelevant
        langRow?.alpha = if (prefs.getBoolean("lang_switch_all", false)) 0.4f else 1f
        updateJoyRow()
        refreshLangRow?.invoke()
        refreshStatus()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) refreshStatus()
    }

    // ------------------------------------------------------------ Material You +

    private fun color(v: View, attr: Int, fallback: Int): Int = MaterialColors.getColor(v.context, attr, fallback)

    private fun setupPlus() {
        val box = findViewById<LinearLayout>(R.id.plus_preview)
        val density = resources.displayMetrics.density
        val margin = (3 * density).toInt()
        previewH = 58f * density - 2 * margin
        val square = prefs.getBoolean("square_mode", false)
        val plus = prefs.getBoolean("plus", false) && !square

        dynamicColors = intArrayOf(
            color(box, com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E.toInt()),
            color(box, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt()),
            color(box, com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt()),
            color(box, com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt()),
            color(box, com.google.android.material.R.attr.colorTertiaryContainer, 0xFF633B48.toInt()),
            color(box, com.google.android.material.R.attr.colorOnTertiaryContainer, 0xFFFFD8E4.toInt()),
            color(box, com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt()),
            color(box, com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72.toInt())
        )
        val cols = previewColors()

        class Spec(val kind: KeyKind, val label: String, val w: Float, val bgI: Int, val fgI: Int)

        val specs = listOf(
            Spec(KeyKind.LETTER, "Q", 1f, 0, 1),
            Spec(KeyKind.LETTER, "W", 1f, 0, 1),
            Spec(KeyKind.SHIFT, "⇧", 1f, 2, 3),
            Spec(KeyKind.SPACE, getString(R.string.space_key), 2.2f, 4, 5),
            Spec(KeyKind.BACKSPACE, "⌫", 1f, 2, 3),
            Spec(KeyKind.ENTER, "↵", 1f, 6, 7)
        )
        for (s in specs) {
            val radii = KeyShapes.normal(s.kind, plus, previewH, density, square)
            val d = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(cols[s.bgI])
                cornerRadii = radii.copyOf()
            }
            val tv = TextView(this).apply {
                text = s.label
                gravity = Gravity.CENTER
                setTextColor(cols[s.fgI])
                textSize = if (s.kind == KeyKind.SPACE) 13f else 18f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                background = d
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, s.w)
            lp.setMargins(margin, margin, margin, margin)
            box.addView(tv, lp)
            previewKeys.add(PreviewKey(tv, s.kind, d, radii.copyOf(), s.bgI, s.fgI))
        }

        val sw = findViewById<MaterialSwitch>(R.id.sw_plus)
        swPlus = sw
        sw.isChecked = plus
        sw.isEnabled = !square
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("plus", checked).apply()
            animatePreview(checked)
        }
    }

    /** The hidden square mode is changed in another screen: bring the card and preview in line when we come back. */
    private fun syncSquare() {
        val sw = swPlus ?: return
        val square = prefs.getBoolean("square_mode", false)
        val plus = prefs.getBoolean("plus", false) && !square
        val density = resources.displayMetrics.density
        sw.setOnCheckedChangeListener(null)
        sw.isChecked = plus
        sw.isEnabled = !square
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("plus", checked).apply()
            animatePreview(checked)
        }
        for (k in previewKeys) {
            val to = KeyShapes.normal(k.kind, plus, previewH, density, square)
            for (i in 0 until 8) k.cur[i] = to[i]
            k.d.cornerRadii = to.copyOf()
        }
    }

    private fun animatePreview(plus: Boolean) {
        val density = resources.displayMetrics.density
        for (k in previewKeys) {
            val from = k.cur.copyOf()
            val to = KeyShapes.normal(k.kind, plus, previewH, density)
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 380
                interpolator = android.view.animation.OvershootInterpolator(1.6f)
                addUpdateListener {
                    val f = it.animatedValue as Float
                    for (i in 0 until 8) k.cur[i] = maxOf(0f, from[i] + (to[i] - from[i]) * f)
                    k.d.cornerRadii = k.cur.copyOf()
                }
                start()
            }
        }
    }

    // ------------------------------------------------------------ settings rows

    private fun addSwitch(
        container: ViewGroup,
        title: String,
        summary: String,
        key: String,
        def: Boolean,
        onChange: ((Boolean) -> Unit)? = null
    ): View {
        val row = layoutInflater.inflate(R.layout.item_switch, container, false)
        row.findViewById<TextView>(R.id.row_title).text = title
        row.findViewById<TextView>(R.id.row_summary).text = summary
        val sw = row.findViewById<MaterialSwitch>(R.id.row_switch)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            onChange?.invoke(checked)
        }
        row.setOnClickListener { sw.toggle() }
        container.addView(row)
        return row
    }

    private fun setEnabledRow(row: View?, enabled: Boolean) {
        row ?: return
        row.alpha = if (enabled) 1f else 0.4f
        row.isEnabled = enabled
        row.isClickable = enabled
        row.findViewById<MaterialSwitch>(R.id.row_switch).isEnabled = enabled
    }

    private fun setupRows() {
        val input = findViewById<LinearLayout>(R.id.group_input)
        val suggestionsOn = prefs.getBoolean("suggestions", true)
        addSwitch(input, getString(R.string.sw_suggestions), getString(R.string.sw_suggestions_s), "suggestions", true) {
            setEnabledRow(autoRow, it)
        }
        autoRow = addSwitch(input, getString(R.string.sw_autocorrect), getString(R.string.sw_autocorrect_s), "autocorrect", true)
        setEnabledRow(autoRow, suggestionsOn)
        addSwitch(input, getString(R.string.sw_numrow), getString(R.string.sw_numrow_s), "number_row", true)
        addSwitch(input, getString(R.string.sw_autocap), getString(R.string.sw_autocap_s), "autocap", true)
        addSwitch(input, getString(R.string.sw_guard), getString(R.string.sw_guard_s), "touch_guard", true)
        addSwitch(input, getString(R.string.sw_hard), getString(R.string.sw_hard_s), "hard_sign_alt", true)
        addSwitch(input, getString(R.string.sw_sym123), getString(R.string.sw_sym123_s), "sym_in_123", true)
        addSwitch(input, getString(R.string.sw_bigletters), getString(R.string.sw_bigletters_s), "big_letters", true)

        val feedback = findViewById<LinearLayout>(R.id.group_feedback)
        addSwitch(feedback, getString(R.string.sw_vibrate), getString(R.string.sw_vibrate_s), "vibrate", true)
        addSwitch(feedback, getString(R.string.sw_sound), getString(R.string.sw_sound_s), "sound", false)

        setupVoice()

        val special = findViewById<LinearLayout>(R.id.group_special)
        addSwitch(special, getString(R.string.sw_swipetype), getString(R.string.sw_swipetype_s), "swipe_typing", true)
        joyRow = addSwitch(special, getString(R.string.sw_joystick), getString(R.string.sw_joystick_s), "space_joystick", false) {
            refreshLangRow?.invoke()
        }
        updateJoyRow()

        val clip = findViewById<LinearLayout>(R.id.group_clip)
        addSwitch(clip, getString(R.string.sw_cliphist), getString(R.string.sw_cliphist_s), "clip_history", true)
        addSwitch(clip, getString(R.string.sw_clipchip), getString(R.string.sw_clipchip_s), "clip_chip", true)
        addSwitch(clip, getString(R.string.sw_clipmask), getString(R.string.sw_clipmask_s), "clip_mask", true)
    }

    /** The joystick needs the space bar free, so it is off while language switching uses a swipe on it. */
    private fun updateJoyRow() {
        val swipe = LangSwitch.mode(prefs) == "swipe" || prefs.getBoolean("lang_switch_all", false)
        setEnabledRow(joyRow, !swipe || prefs.getBoolean("space_joystick", false))
    }

    private fun setupVoice() {
        val box = findViewById<LinearLayout>(R.id.group_voice)
        val group = findViewById<RadioGroup>(R.id.voice_lang_group)
        val label = findViewById<View>(R.id.voice_lang_label)
        fun applyEnabled(on: Boolean) {
            val a = if (on) 1f else 0.4f
            label.alpha = a
            group.alpha = a
            for (i in 0 until group.childCount) group.getChildAt(i).isEnabled = on
        }
        addSwitch(box, getString(R.string.sw_voice), getString(R.string.sw_voice_s), "voice_enabled", true) {
            applyEnabled(it)
        }
        applyEnabled(prefs.getBoolean("voice_enabled", true))
        group.check(
            when (prefs.getString("voice_lang", "any")) {
                "ru" -> R.id.voice_ru
                "uk" -> R.id.voice_uk
                "en" -> R.id.voice_en
                else -> R.id.voice_any
            }
        )
        group.setOnCheckedChangeListener { _, id ->
            val v = when (id) {
                R.id.voice_ru -> "ru"
                R.id.voice_uk -> "uk"
                R.id.voice_en -> "en"
                else -> "any"
            }
            prefs.edit().putString("voice_lang", v).apply()
        }
        findViewById<View>(R.id.btn_mic_perm).setOnClickListener {
            startActivity(Intent(this, VoicePermissionActivity::class.java))
        }
    }

    private fun setupHeight() {
        val label = findViewById<TextView>(R.id.height_label)
        val slider = findViewById<Slider>(R.id.slider_height)
        val h = prefs.getInt("key_height", 48).coerceIn(40, 64)
        slider.value = h.toFloat()
        label.text = getString(R.string.height_label, h)
        slider.addOnChangeListener { _, value, _ ->
            val v = value.toInt()
            prefs.edit().putInt("key_height", v).apply()
            label.text = getString(R.string.height_label, v)
        }
    }

    // ------------------------------------------------------------ status

    private fun isEnabled(): Boolean =
        imm.enabledInputMethodList.any { it.packageName == packageName }

    private fun isDefault(): Boolean {
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        return current?.startsWith("$packageName/") == true
    }

    private fun refreshStatus() {
        // settings stay locked until the keyboard is enabled and chosen as the default one
        val unlocked = isEnabled() && isDefault()
        val content = findViewById<ViewGroup>(R.id.content_root)
        for (i in 1 until content.childCount) content.getChildAt(i).visibility = if (unlocked) View.VISIBLE else View.GONE
        bottomBar?.visibility = if (unlocked) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btn_mic_perm).visibility =
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) View.GONE else View.VISIBLE
        val enabled = isEnabled()
        val default = isDefault()
        step1.text = getString(if (enabled) R.string.step1_on else R.string.step1_off)
        step2.text = getString(if (default) R.string.step2_on else R.string.step2_off)
        when {
            !enabled -> {
                heroTitle.text = getString(R.string.setup_title)
                heroSub.text = getString(R.string.setup_sub)
                btnAction.text = getString(R.string.btn_enable)
                btnAction.visibility = View.VISIBLE
            }
            !default -> {
                heroTitle.text = getString(R.string.almost_title)
                heroSub.text = getString(R.string.almost_sub)
                btnAction.text = getString(R.string.btn_default)
                btnAction.visibility = View.VISIBLE
            }
            else -> {
                heroTitle.text = getString(R.string.active_title)
                heroSub.text = getString(R.string.active_sub)
                btnAction.visibility = View.GONE
            }
        }

        val names = assets.list("")?.toList() ?: emptyList()
        val ru = names.contains("dict_ru.txt")
        val en = names.contains("dict_en.txt")
        findViewById<TextView>(R.id.dict_status).text = getString(
            when {
                ru && en -> R.string.dict_both
                ru -> R.string.dict_ru
                en -> R.string.dict_en
                else -> R.string.dict_none
            }
        )
    }
}
