package com.materialyou.keyboard

import android.animation.ValueAnimator
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var imm: InputMethodManager
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var step1: TextView
    private lateinit var step2: TextView
    private lateinit var btnAction: MaterialButton
    private var autoRow: View? = null
    private var joyRow: View? = null
    private var emojiRow: View? = null
    private var barCtl: BottomBar.Controller? = null
    private var refreshLangRow: (() -> Unit)? = null
    private var langRow: LinearLayout? = null

    private fun color(v: View, attr: Int, fallback: Int): Int = MaterialColors.getColor(v.context, attr, fallback)

    private fun setupLangSwitch() {
        val row = findViewById<LinearLayout>(R.id.langswitch_row)
        langRow = row
        val density = resources.displayMetrics.density
        val bg = color(row, com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt())
        val fg = color(row, com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt())
        val onSurface = color(row, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val outline = color(row, com.google.android.material.R.attr.colorOutline, 0xFF938F99.toInt())
        val items = listOf(
            Triple("menu", R.drawable.ic_menu, R.string.ls_menu),
            Triple("globe", R.drawable.ic_globe, R.string.ls_globe),
            Triple("swipe", R.drawable.ic_swipe, R.string.ls_swipe),
            Triple("button", R.drawable.ic_translate, R.string.ls_button)
        )
        val cells = ArrayList<Triple<String, View, TextView>>()
        fun refresh() {
            val cur = LangSwitch.mode(prefs)
            val joyOn = prefs.getBoolean("space_joystick", false)
            for ((id, ring, label) in cells) {
                val on = id == cur
                (ring.background as GradientDrawable).setStroke(
                    ((if (on) 3 else 1) * density).toInt(), if (on) onSurface else outline
                )
                label.alpha = if (on) 1f else 0.7f
                if (id == "swipe" && joyOn) {
                    (ring.parent as? View)?.parent?.let { (it as View).alpha = 0.35f }
                    label.alpha = 0.35f
                } else (ring.parent as? View)?.parent?.let { (it as View).alpha = 1f }
            }
            updateJoyRow()
        }
        for ((id, icon, name) in items) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                isFocusable = true
            }
            val frame = android.widget.FrameLayout(this)
            val disc = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(bg)
                }
            }
            frame.addView(disc, android.widget.FrameLayout.LayoutParams((40 * density).toInt(), (40 * density).toInt(), Gravity.CENTER))
            val iv = android.widget.ImageView(this).apply {
                setImageResource(icon)
                setColorFilter(fg)
            }
            frame.addView(iv, android.widget.FrameLayout.LayoutParams((22 * density).toInt(), (22 * density).toInt(), Gravity.CENTER))
            val ring = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0x00000000)
                }
            }
            frame.addView(ring, android.widget.FrameLayout.LayoutParams((48 * density).toInt(), (48 * density).toInt(), Gravity.CENTER))
            cell.addView(frame, LinearLayout.LayoutParams((52 * density).toInt(), (52 * density).toInt()))
            val label = TextView(this).apply {
                text = getString(name)
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
                setTextColor(onSurface)
            }
            cell.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            cell.setOnClickListener {
                if (prefs.getBoolean("lang_switch_all", false)) return@setOnClickListener
                if (id == "swipe" && prefs.getBoolean("space_joystick", false)) return@setOnClickListener
                prefs.edit().putString(LangSwitch.KEY, id).apply()
                refresh()
            }
            row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            cells.add(Triple(id, ring, label))
        }
        refresh()
        refreshLangRow = { refresh() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // status bar icons follow the theme: dark icons on a light bar, light icons on a dark bar
        androidx.core.view.WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
            (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) !=
                    android.content.res.Configuration.UI_MODE_NIGHT_YES

        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        imm = getSystemService(InputMethodManager::class.java)

        heroTitle = findViewById(R.id.hero_title)
        heroSub = findViewById(R.id.hero_sub)
        step1 = findViewById(R.id.step1)
        step2 = findViewById(R.id.step2)
        btnAction = findViewById(R.id.btn_action)
        btnAction.setOnClickListener {
            if (!isEnabled()) {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            } else if (!isDefault()) {
                imm.showInputMethodPicker()
            }
        }

        barCtl = BottomBar.attach(this, BottomBar.SETTINGS)

        setupRound()
        setupShortcuts()
        setupMyEmoji()
        setupLangSwitch()
        setupRows()
        setupHeight()

        findViewById<View>(R.id.btn_clear_clips).setOnClickListener {
            ClipStore(prefs).clearAll()
            com.google.android.material.snackbar.Snackbar
                .make(it, getString(R.string.clips_cleared), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT)
                .show()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        barCtl?.animateFrom(intent.getIntExtra(BottomBar.EXTRA_FROM, BottomBar.SETTINGS))
    }

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        barCtl?.feed(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        // the hidden "all methods at once" switch makes the single-choice row irrelevant
        langRow?.alpha = if (prefs.getBoolean("lang_switch_all", false)) 0.4f else 1f
        updateJoyRow()
        refreshLangRow?.invoke()
        refreshStatus()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) refreshStatus()
    }

    // ------------------------------------------------------------ settings rows

    private fun addSwitch(
        container: ViewGroup,
        title: String,
        summary: String,
        key: String,
        def: Boolean,
        onChange: ((Boolean) -> Unit)? = null
    ): View {
        val row = layoutInflater.inflate(R.layout.item_switch, container, false)
        row.findViewById<TextView>(R.id.row_title).text = title
        row.findViewById<TextView>(R.id.row_summary).text = summary
        val sw = row.findViewById<MaterialSwitch>(R.id.row_switch)
        // every row shares the id row_switch: letting Android save/restore their state would copy one switch's
        // value into all of them (and, through the listener below, into the saved settings)
        row.isSaveFromParentEnabled = false
        row.isSaveEnabled = false
        sw.isSaveEnabled = false
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            onChange?.invoke(checked)
        }
        row.setOnClickListener { sw.toggle() }
        container.addView(row)
        return row
    }

    private fun setEnabledRow(row: View?, enabled: Boolean) {
        row ?: return
        row.alpha = if (enabled) 1f else 0.4f
        row.isEnabled = enabled
        row.isClickable = enabled
        row.findViewById<MaterialSwitch>(R.id.row_switch).isEnabled = enabled
    }

    private fun setupRows() {
        val input = findViewById<LinearLayout>(R.id.group_input)
        val suggestionsOn = prefs.getBoolean("suggestions", true)
        addSwitch(input, getString(R.string.sw_suggestions), getString(R.string.sw_suggestions_s), "suggestions", true) {
            setEnabledRow(autoRow, it)
        }
        autoRow = addSwitch(input, getString(R.string.sw_autocorrect), getString(R.string.sw_autocorrect_s), "autocorrect", true)
        setEnabledRow(autoRow, suggestionsOn)
        addSwitch(input, getString(R.string.sw_numrow), getString(R.string.sw_numrow_s), "number_row", true)
        addSwitch(input, getString(R.string.sw_autocap), getString(R.string.sw_autocap_s), "autocap", true)
        addSwitch(input, getString(R.string.sw_guard), getString(R.string.sw_guard_s), "touch_guard", true)
        addSwitch(input, getString(R.string.sw_hard), getString(R.string.sw_hard_s), "hard_sign_alt", true)
        addSwitch(input, getString(R.string.sw_sym123), getString(R.string.sw_sym123_s), "sym_in_123", true)
        emojiRow = addSwitch(input, getString(R.string.sw_hideemoji), getString(R.string.sw_hideemoji_s), "hide_emoji_btn", false)
        addSwitch(input, getString(R.string.sw_bigletters), getString(R.string.sw_bigletters_s), "big_letters", true)

        val feedback = findViewById<LinearLayout>(R.id.group_feedback)
        addSwitch(feedback, getString(R.string.sw_vibrate), getString(R.string.sw_vibrate_s), "vibrate", true)
        addSwitch(feedback, getString(R.string.sw_sound), getString(R.string.sw_sound_s), "sound", false)


        val special = findViewById<LinearLayout>(R.id.group_special)
        addSwitch(special, getString(R.string.sw_profanity), getString(R.string.sw_profanity_s), "profanity_filter", true)
        addSwitch(special, getString(R.string.sw_swipetype), getString(R.string.sw_swipetype_s), "swipe_typing", true)
        joyRow = addSwitch(special, getString(R.string.sw_joystick), getString(R.string.sw_joystick_s), "space_joystick", false) {
            refreshLangRow?.invoke()
        }
        updateJoyRow()

        val clip = findViewById<LinearLayout>(R.id.group_clip)
        addSwitch(clip, getString(R.string.sw_cliphist), getString(R.string.sw_cliphist_s), "clip_history", true)
        addSwitch(clip, getString(R.string.sw_clipchip), getString(R.string.sw_clipchip_s), "clip_chip", true)
        addSwitch(clip, getString(R.string.sw_clipmask), getString(R.string.sw_clipmask_s), "clip_mask", true)
    }

    /** The joystick needs the space bar free, so it is off while language switching uses a swipe on it. */
    private fun updateJoyRow() {
        setEnabledRow(emojiRow, LangSwitch.mode(prefs) == "button" && !prefs.getBoolean("lang_switch_all", false))
        val swipe = LangSwitch.mode(prefs) == "swipe" || prefs.getBoolean("lang_switch_all", false)
        setEnabledRow(joyRow, !swipe || prefs.getBoolean("space_joystick", false))
    }

    // ---- collapsible groups (see Groups.kt)
    private fun setupGroups() = Groups.scan(this, prefs, "groups_open")

    private val pickEmojiFile = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        val text = try {
            contentResolver.openInputStream(uri)?.use { s ->
                val buf = ByteArray(500_000)
                var n = 0
                while (n < buf.size) {
                    val r = s.read(buf, n, buf.size - n)
                    if (r < 0) break
                    n += r
                }
                String(buf, 0, n, Charsets.UTF_8)
            }
        } catch (_: Throwable) {
            null
        }
        if (text.isNullOrBlank()) {
            android.widget.Toast.makeText(this, R.string.myemoji_fail, android.widget.Toast.LENGTH_SHORT).show()
        } else {
            val et = findViewById<android.widget.EditText>(R.id.myemoji_edit)
            val cur = et.text?.toString().orEmpty()
            et.setText(if (cur.isBlank()) text.trim() else cur.trim() + " " + text.trim())
            android.widget.Toast.makeText(this, R.string.myemoji_loaded, android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupMyEmoji() {
        val et = findViewById<android.widget.EditText>(R.id.myemoji_edit)
        et.isSaveEnabled = false
        et.setText(prefs.getString("my_emoji", ""))
        findViewById<View>(R.id.btn_myemoji_file).setOnClickListener { pickEmojiFile.launch("*/*") }
        et.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                prefs.edit().putString("my_emoji", s?.toString() ?: "").apply()
            }
        })
    }

    private fun setupShortcuts() {
        val et = findViewById<android.widget.EditText>(R.id.shortcuts_edit)
        et.isSaveEnabled = false
        et.setText(prefs.getString("shortcuts", ""))
        et.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                prefs.edit().putString("shortcuts", s?.toString() ?: "").apply()
            }
        })
    }

    private fun setupRound() {
        val label = findViewById<TextView>(R.id.round_label)
        val slider = findViewById<Slider>(R.id.slider_round)
        val v0 = prefs.getInt("key_round", 57).coerceIn(0, 100)
        slider.value = v0.toFloat()
        label.text = getString(R.string.round_label, v0)
        slider.addOnChangeListener { _, value, fromUser ->
            val v = value.toInt()
            label.text = getString(R.string.round_label, v)
            if (fromUser) {
                prefs.edit().putInt("key_round", v).apply()
            }
        }
    }

    private fun setupHeight() {
        val label = findViewById<TextView>(R.id.height_label)
        val slider = findViewById<Slider>(R.id.slider_height)
        val h = prefs.getInt("key_height", 48).coerceIn(40, 64)
        slider.value = h.toFloat()
        label.text = getString(R.string.height_label, h)
        slider.addOnChangeListener { _, value, _ ->
            val v = value.toInt()
            prefs.edit().putInt("key_height", v).apply()
            label.text = getString(R.string.height_label, v)
        }
    }

    // ------------------------------------------------------------ status

    private fun isEnabled(): Boolean =
        imm.enabledInputMethodList.any { it.packageName == packageName }

    private fun isDefault(): Boolean {
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        return current?.startsWith("$packageName/") == true
    }

    /** Until the keyboard is set up, the "make it default" prompt fills the whole app instead of a small card. */
    private fun applyHeroMode(full: Boolean) {
        val appBar = findViewById<View>(R.id.app_bar)
        val scroll = findViewById<View>(R.id.scroll_main)
        val card = findViewById<View>(R.id.hero_card)
        val content = findViewById<View>(R.id.content_root)
        appBar.visibility = if (full) View.GONE else View.VISIBLE
        val d = resources.displayMetrics.density
        content.setPadding(content.paddingLeft, (4 * d).toInt(), content.paddingRight, ((if (full) 16 else 120) * d).toInt())
        fun fit() {
            if (full && scroll.height <= 0) return // not measured yet
            val lp = card.layoutParams
            val h = if (full) scroll.height - (20 * d).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT
            if (lp.height != h) {
                lp.height = h
                card.layoutParams = lp
            }
        }
        fit()
        if (full) scroll.post { fit() }
    }

    private fun refreshStatus() {
        // settings stay locked until the keyboard is enabled and chosen as the default one
        val unlocked = isEnabled() && isDefault()
        val content = findViewById<ViewGroup>(R.id.content_root)
        for (i in 1 until content.childCount) content.getChildAt(i).visibility = if (unlocked) View.VISIBLE else View.GONE
        // the loop above reopens every card; put the collapsed groups back
        if (unlocked) setupGroups()
        barCtl?.view?.visibility = if (unlocked) View.VISIBLE else View.GONE
        applyHeroMode(!unlocked)
        val enabled = isEnabled()
        val default = isDefault()
        step1.text = getString(if (enabled) R.string.step1_on else R.string.step1_off)
        step2.text = getString(if (default) R.string.step2_on else R.string.step2_off)
        when {
            !enabled -> {
                heroTitle.text = getString(R.string.setup_title)
                heroSub.text = getString(R.string.setup_sub)
                btnAction.text = getString(R.string.btn_enable)
                btnAction.visibility = View.VISIBLE
            }
            !default -> {
                heroTitle.text = getString(R.string.almost_title)
                heroSub.text = getString(R.string.almost_sub)
                btnAction.text = getString(R.string.btn_default)
                btnAction.visibility = View.VISIBLE
            }
            else -> {
                heroTitle.text = getString(R.string.active_title)
                heroSub.text = getString(R.string.active_sub)
                btnAction.visibility = View.GONE
            }
        }

        val names = assets.list("")?.toList() ?: emptyList()
        val ru = names.contains("dict_ru.txt")
        val en = names.contains("dict_en.txt")
        findViewById<TextView>(R.id.dict_status).text = getString(
            when {
                ru && en -> R.string.dict_both
                ru -> R.string.dict_ru
                en -> R.string.dict_en
                else -> R.string.dict_none
            }
        )
    }
}
