package com.materialyou.keyboard

import android.animation.ValueAnimator
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.color.MaterialColors
import com.google.android.material.slider.Slider

/** The Material You + card (switch, cookie bar and key preview); lives in the Themes tab. */
class PlusCard(private val a: AppCompatActivity, private val prefs: SharedPreferences) {

    private fun <T : View> findViewById(id: Int): T = a.findViewById(id)
    private val resources get() = a.resources
    private fun getString(id: Int) = a.getString(id)
    private val layoutInflater get() = a.layoutInflater

    private class PreviewKey(
        val view: TextView, val kind: KeyKind, val d: GradientDrawable, val cur: FloatArray,
        val bgI: Int, val fgI: Int
    )

    private val previewKeys = ArrayList<PreviewKey>()
    private var previewH = 0f
    private var dynamicColors = IntArray(8)
    private var slider: Slider? = null

    private fun level(): Int {
        if (prefs.getBoolean("square_mode", false) || !prefs.getBoolean("plus", false)) return 1
        return if (prefs.getBoolean("plus_shapes", true)) 3 else 2
    }

    private fun showLevel(l: Int) {
        findViewById<TextView>(R.id.plus_level_text).text = getString(
            when (l) { 1 -> R.string.plus_l1; 2 -> R.string.plus_l2; else -> R.string.plus_l3 })
        findViewById<TextView>(R.id.plus_level_sub).text = getString(
            when (l) { 1 -> R.string.plus_l1_s; 2 -> R.string.plus_l2_s; else -> R.string.plus_l3_s })
    }

    private fun applyLevel(l: Int) {
        prefs.edit().putBoolean("plus", l >= 2).putBoolean("plus_shapes", l == 3).apply()
        showLevel(l)
        animatePreview(l >= 2)
    }

    private fun isDark(): Boolean =
        (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES

    /** letter, onSurface, function, onFunction, tertiary, onTertiary, primary, onPrimary */
    private fun previewColors(): IntArray {
        val t = Themes.colors(prefs.getString(Themes.KEY, "system") ?: "system", isDark()) ?: return dynamicColors
        return intArrayOf(t.space, t.onSurface, t.function, t.onFunction, t.tertiary, t.onTertiary, t.primary, t.onPrimary)
    }

    fun repaint() {
        if (previewKeys.isEmpty()) return
        paintBar()
        val cols = previewColors()
        for (k in previewKeys) {
            k.d.setColor(cols[k.bgI])
            k.view.setTextColor(cols[k.fgI])
        }
    }

    // ------------------------------------------------------------ Material You +

    private fun color(v: View, attr: Int, fallback: Int): Int = MaterialColors.getColor(v.context, attr, fallback)

    fun setup() {
        val box = findViewById<LinearLayout>(R.id.plus_preview)
        val density = resources.displayMetrics.density
        val margin = (3 * density).toInt()
        previewH = 58f * density - 2 * margin
        val square = prefs.getBoolean("square_mode", false)
        val plus = prefs.getBoolean("plus", false) && !square

        dynamicColors = intArrayOf(
            color(box, com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E.toInt()),
            color(box, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt()),
            color(box, com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt()),
            color(box, com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt()),
            color(box, com.google.android.material.R.attr.colorTertiaryContainer, 0xFF633B48.toInt()),
            color(box, com.google.android.material.R.attr.colorOnTertiaryContainer, 0xFFFFD8E4.toInt()),
            color(box, com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt()),
            color(box, com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72.toInt())
        )
        val cols = previewColors()

        class Spec(val kind: KeyKind, val label: String, val w: Float, val bgI: Int, val fgI: Int)

        val specs = listOf(
            Spec(KeyKind.LETTER, "Q", 1f, 0, 1),
            Spec(KeyKind.LETTER, "W", 1f, 0, 1),
            Spec(KeyKind.SHIFT, "⇧", 1f, 2, 3),
            Spec(KeyKind.SPACE, getString(R.string.space_key), 2.2f, 4, 5),
            Spec(KeyKind.BACKSPACE, "⌫", 1f, 2, 3),
            Spec(KeyKind.ENTER, "↵", 1f, 6, 7)
        )
        for (s in specs) {
            val radii = KeyShapes.normal(s.kind, plus, previewH, density, square, prefs.getBoolean("plus_shapes", true), KeyShapes.round(prefs))
            val d = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(cols[s.bgI])
                cornerRadii = radii.copyOf()
            }
            val tv = TextView(a).apply {
                text = s.label
                gravity = Gravity.CENTER
                setTextColor(cols[s.fgI])
                textSize = if (s.kind == KeyKind.SPACE) 13f else 18f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                background = d
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, s.w)
            lp.setMargins(margin, margin, margin, margin)
            box.addView(tv, lp)
            previewKeys.add(PreviewKey(tv, s.kind, d, radii.copyOf(), s.bgI, s.fgI))
        }

        paintBar()
        val sl = findViewById<Slider>(R.id.slider_plus)
        slider = sl
        sl.isSaveEnabled = false
        sl.value = level().toFloat()
        sl.isEnabled = !square
        showLevel(level())
        sl.setLabelFormatter { it.toInt().toString() }
        sl.addOnChangeListener { _, v, fromUser ->
            if (fromUser) applyLevel(v.toInt())
        }
        setupAdvanced()
    }

    /** Closed arrow in a circle (Material You blue); opens the advanced Material You+ settings. */
    private fun setupAdvanced() {
        val density = resources.displayMetrics.density
        val box = findViewById<FrameLayout>(R.id.plus_arrow)
        val adv = findViewById<LinearLayout>(R.id.plus_adv)
        val bg = color(box, com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt())
        val fg = color(box, com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72.toInt())
        val onSurface = color(box, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        box.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(bg)
        }
        val arrow = ArrowDrawable(fg, (40 * density).toInt())
        box.foreground = arrow

        adv.removeAllViews()
        adv.addView(TextView(a).apply {
            text = getString(R.string.plus_adv_anim)
            textSize = 14f
            setTextColor(onSurface)
        })
        val group = com.google.android.material.button.MaterialButtonToggleGroup(a).apply {
            isSingleSelection = true
            isSelectionRequired = true
        }
        val grow = com.google.android.material.button.MaterialButton(a, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = getString(R.string.plus_anim_grow)
            id = View.generateViewId()
            isCheckable = true
        }
        val shrink = com.google.android.material.button.MaterialButton(a, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = getString(R.string.plus_anim_shrink)
            id = View.generateViewId()
            isCheckable = true
        }
        group.addView(shrink)
        group.addView(grow)
        group.check(if (prefs.getString("press_anim", "shrink") == "grow") grow.id else shrink.id)
        group.addOnButtonCheckedListener { _, id, checked ->
            if (checked) prefs.edit().putString("press_anim", if (id == grow.id) "grow" else "shrink").apply()
        }
        adv.addView(group, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (8 * density).toInt()
        })

        var open = false
        var anim: ValueAnimator? = null
        box.setOnClickListener {
            open = !open
            anim?.cancel()
            val from = arrow.progress
            val to = if (open) 1f else 0f
            if (open) {
                adv.alpha = 0f
                adv.visibility = View.VISIBLE
            }
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 260
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener {
                    val f = it.animatedValue as Float
                    arrow.progress = from + (to - from) * f
                    adv.alpha = if (open) f else 1f - f
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: android.animation.Animator) {
                        if (!open) adv.visibility = View.GONE
                    }
                })
                start()
            }
        }
    }

    /** The hidden square mode is changed in another screen: bring the card and preview in line when we come back. */
    fun sync() {
        val sl = slider ?: return
        val square = prefs.getBoolean("square_mode", false)
        val plus = prefs.getBoolean("plus", false) && !square
        val density = resources.displayMetrics.density
        sl.value = level().toFloat()
        sl.isEnabled = !square
        showLevel(level())
        paintBar()
        for (k in previewKeys) {
            val to = KeyShapes.normal(k.kind, plus, previewH, density, square, prefs.getBoolean("plus_shapes", true), KeyShapes.round(prefs))
            for (i in 0 until 8) k.cur[i] = to[i]
            k.d.cornerRadii = to.copyOf()
        }
    }

    /** Banner row of top-bar buttons: cookies with Material You + (and shapes on), gray circles otherwise. */
    private fun paintBar() {
        val bar = findViewById<LinearLayout>(R.id.plus_bar) ?: return
        val dm = resources.displayMetrics.density
        val square = prefs.getBoolean("square_mode", false)
        val cookie = prefs.getBoolean("plus", false) && !square && prefs.getBoolean("plus_shapes", true)
        bar.removeAllViews()
        val pc = previewColors()
        val bg = if (cookie) pc[6] else dynamicColors[0]
        val fg = if (cookie) pc[7] else dynamicColors[1]
        for (res in listOf(R.drawable.ic_clipboard, R.drawable.ic_mic, 0)) {
            val b = FrameLayout(a)
            if (cookie) {
                b.background = CookieDrawable(8, (36 * dm).toInt()).also { it.setColor(bg) }
            } else {
                val oval = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(bg)
                }
                b.background = android.graphics.drawable.InsetDrawable(oval, (4 * dm).toInt(), (3 * dm).toInt(), (4 * dm).toInt(), (3 * dm).toInt())
            }
            val iv = android.widget.ImageView(a)
            if (res != 0) {
                iv.setImageResource(res)
                iv.setColorFilter(fg)
            } else {
                iv.setImageDrawable(ArrowDrawable(fg, (28 * dm).toInt()))
            }
            b.addView(iv, FrameLayout.LayoutParams((24 * dm).toInt(), (24 * dm).toInt(), Gravity.CENTER))
            bar.addView(b, LinearLayout.LayoutParams((52 * dm).toInt(), (44 * dm).toInt()).apply {
                setMargins((6 * dm).toInt(), 0, (6 * dm).toInt(), 0)
            })
        }
    }

    private fun animatePreview(plus: Boolean) {
        paintBar()
        val density = resources.displayMetrics.density
        for (k in previewKeys) {
            val from = k.cur.copyOf()
            val to = KeyShapes.normal(k.kind, plus, previewH, density, false, prefs.getBoolean("plus_shapes", true), KeyShapes.round(prefs))
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 380
                interpolator = android.view.animation.OvershootInterpolator(1.6f)
                addUpdateListener {
                    val f = it.animatedValue as Float
                    for (i in 0 until 8) k.cur[i] = maxOf(0f, from[i] + (to[i] - from[i]) * f)
                    k.d.cornerRadii = k.cur.copyOf()
                }
                start()
            }
        }
    }
}
