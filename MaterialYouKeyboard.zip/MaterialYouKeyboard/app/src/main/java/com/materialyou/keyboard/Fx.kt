package com.materialyou.keyboard

import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils

/** Gradient effects for the keyboard background. */
object Fx {
    const val KEY = "grad_fx"
    val IDS = listOf("down", "up", "glow", "diag")

    /** [bg] is the plain keyboard colour, [accent] the theme colour that fades into it. */
    fun drawable(id: String?, bg: Int, accent: Int): Drawable {
        val tint = ColorUtils.blendARGB(bg, accent, 0.34f)
        return when (id) {
            "down" -> GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(tint, bg))
            "up" -> GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(tint, bg))
            "glow" -> GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bg, tint, bg))
            "diag" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tint, bg))
            else -> ColorDrawable(bg)
        }
    }
}

/** Draws another drawable with rounded top corners (the keyboard background). */
class TopRoundDrawable(private val inner: android.graphics.drawable.Drawable, private val radius: Float) :
    android.graphics.drawable.Drawable() {
    private val path = android.graphics.Path()

    override fun onBoundsChange(b: android.graphics.Rect) {
        inner.bounds = b
        path.reset()
        path.addRoundRect(
            android.graphics.RectF(b),
            floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f),
            android.graphics.Path.Direction.CW
        )
    }

    override fun draw(c: android.graphics.Canvas) {
        c.save()
        c.clipPath(path)
        inner.draw(c)
        c.restore()
    }

    override fun setAlpha(alpha: Int) { inner.alpha = alpha }
    override fun setColorFilter(cf: android.graphics.ColorFilter?) { inner.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
}
