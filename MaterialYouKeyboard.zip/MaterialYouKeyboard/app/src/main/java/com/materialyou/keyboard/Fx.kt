package com.materialyou.keyboard

import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils

/** Gradient effects for the keyboard background. */
object Fx {
    const val KEY = "grad_fx"
    val IDS = listOf("down", "up", "glow", "diag")

    /** [bg] is the plain keyboard colour, [accent] the theme colour that fades into it. */
    fun drawable(id: String?, bg: Int, accent: Int): Drawable {
        val tint = ColorUtils.blendARGB(bg, accent, 0.34f)
        return when (id) {
            "down" -> GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(tint, bg))
            "up" -> GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(tint, bg))
            "glow" -> GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bg, tint, bg))
            "diag" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tint, bg))
            else -> ColorDrawable(bg)
        }
    }
}

/** Draws another drawable with rounded top corners (the keyboard background). */
class TopRoundDrawable(private val inner: android.graphics.drawable.Drawable, private val radius: Float) :
    android.graphics.drawable.Drawable() {
    private val path = android.graphics.Path()

    override fun onBoundsChange(b: android.graphics.Rect) {
        inner.bounds = b
        path.reset()
        path.addRoundRect(
            android.graphics.RectF(b),
            floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f),
            android.graphics.Path.Direction.CW
        )
    }

    override fun draw(c: android.graphics.Canvas) {
        c.save()
        c.clipPath(path)
        inner.draw(c)
        c.restore()
    }

    override fun setAlpha(alpha: Int) { inner.alpha = alpha }
    override fun setColorFilter(cf: android.graphics.ColorFilter?) { inner.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
}

/** A photo scaled to fill the keyboard (centre crop) with a translucent tint so keys stay readable. */
class PhotoBgDrawable(private val bmp: android.graphics.Bitmap, private val scrim: Int) : android.graphics.drawable.Drawable() {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
    private val tint = android.graphics.Paint().apply { color = androidx.core.graphics.ColorUtils.setAlphaComponent(scrim, 70) }
    private val src = android.graphics.Rect()

    override fun draw(c: android.graphics.Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        // centre crop: take the part of the bitmap with the same aspect as the bounds
        val ba = b.width().toFloat() / b.height()
        val ia = bmp.width.toFloat() / bmp.height
        if (ia > ba) {
            val w = (bmp.height * ba).toInt()
            val x = (bmp.width - w) / 2
            src.set(x, 0, x + w, bmp.height)
        } else {
            val h = (bmp.width / ba).toInt()
            val y = (bmp.height - h) / 2
            src.set(0, y, bmp.width, y + h)
        }
        c.drawBitmap(bmp, src, b, paint)
        c.drawRect(b, tint)
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(cf: android.graphics.ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = android.graphics.PixelFormat.OPAQUE
}
