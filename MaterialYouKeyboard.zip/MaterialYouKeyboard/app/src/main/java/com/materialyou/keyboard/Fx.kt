package com.materialyou.keyboard

import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils

/** Gradient effects for the keyboard background. */
object Fx {
    const val KEY = "grad_fx"
    val IDS = listOf("down", "up", "glow", "diag", "free")

    /** [bg] is the plain keyboard colour, [accent] the theme colour that fades into it. */
    fun drawable(id: String?, bg: Int, accent: Int, x: Float = 0.5f, y: Float = 0.3f, size: Float = 0.7f): Drawable {
        val tint = ColorUtils.blendARGB(bg, accent, 0.34f)
        return when (id) {
            "free" -> GlowDrawable(bg, ColorUtils.blendARGB(bg, accent, 0.5f), x, y, size)
            "down" -> GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(tint, bg))
            "up" -> GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(tint, bg))
            "glow" -> GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bg, tint, bg))
            "diag" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tint, bg))
            else -> ColorDrawable(bg)
        }
    }
}

/** Draws another drawable with rounded top corners (the keyboard background). */
class TopRoundDrawable(private val inner: android.graphics.drawable.Drawable, private val radius: Float) :
    android.graphics.drawable.Drawable() {
    private val path = android.graphics.Path()

    override fun onBoundsChange(b: android.graphics.Rect) {
        inner.bounds = b
        path.reset()
        path.addRoundRect(
            android.graphics.RectF(b),
            floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f),
            android.graphics.Path.Direction.CW
        )
    }

    override fun draw(c: android.graphics.Canvas) {
        c.save()
        c.clipPath(path)
        inner.draw(c)
        c.restore()
    }

    override fun setAlpha(alpha: Int) { inner.alpha = alpha }
    override fun setColorFilter(cf: android.graphics.ColorFilter?) { inner.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
}

/** A photo scaled to fill the keyboard (centre crop) with a translucent tint so keys stay readable. */
class PhotoBgDrawable(private val bmp: android.graphics.Bitmap, private val scrim: Int) : android.graphics.drawable.Drawable() {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
    private val tint = android.graphics.Paint().apply { color = androidx.core.graphics.ColorUtils.setAlphaComponent(scrim, 70) }
    private val src = android.graphics.Rect()

    override fun draw(c: android.graphics.Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        // centre crop: take the part of the bitmap with the same aspect as the bounds
        val ba = b.width().toFloat() / b.height()
        val ia = bmp.width.toFloat() / bmp.height
        if (ia > ba) {
            val w = (bmp.height * ba).toInt()
            val x = (bmp.width - w) / 2
            src.set(x, 0, x + w, bmp.height)
        } else {
            val h = (bmp.width / ba).toInt()
            val y = (bmp.height - h) / 2
            src.set(0, y, bmp.width, y + h)
        }
        c.drawBitmap(bmp, src, b, paint)
        c.drawRect(b, tint)
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(cf: android.graphics.ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = android.graphics.PixelFormat.OPAQUE
}


/** A round glow of the theme colour whose centre ([cx], [cy], fractions of the size) is placed by the user. */
class GlowDrawable(private val bg: Int, private val tint: Int, private val cx: Float, private val cy: Float, private val size: Float) :
    android.graphics.drawable.Drawable() {
    private val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val line = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.STROKE }
    private val rect = android.graphics.RectF()
    var round = 0f
    var strokeW = 0f
    var strokeColor = 0

    override fun onBoundsChange(b: android.graphics.Rect) {
        val r = maxOf(maxOf(b.width(), b.height()) * size, 1f)
        fill.shader = android.graphics.RadialGradient(
            b.left + b.width() * cx, b.top + b.height() * cy, r, tint, bg, android.graphics.Shader.TileMode.CLAMP
        )
    }

    override fun draw(c: android.graphics.Canvas) {
        rect.set(bounds)
        if (round > 0f) c.drawRoundRect(rect, round, round, fill) else c.drawRect(rect, fill)
        if (strokeW > 0f) {
            line.strokeWidth = strokeW
            line.color = strokeColor
            val h = strokeW / 2f
            rect.inset(h, h)
            if (round > 0f) c.drawRoundRect(rect, round - h, round - h, line) else c.drawRect(rect, line)
        }
    }

    override fun setAlpha(alpha: Int) { fill.alpha = alpha }
    override fun setColorFilter(cf: android.graphics.ColorFilter?) { fill.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
}

/** Preview of the free glow: drag a finger over it to move the glow. [onDone] gets the final position (fractions). */
class GlowPad(ctx: android.content.Context) : android.view.View(ctx) {
    var bg = 0
    var accent = 0
    var ring = 0
    var gx = 0.5f
    var gy = 0.3f
    var size = 0.7f
    var onDone: ((Float, Float) -> Unit)? = null
    private val dot = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.STROKE }

    override fun onDraw(c: android.graphics.Canvas) {
        val d = resources.displayMetrics.density
        val g = GlowDrawable(bg, ColorUtils.blendARGB(bg, accent, 0.5f), gx, gy, size)
        g.round = 22f * d
        g.strokeW = 1f * d
        g.strokeColor = ring and 0x66FFFFFF
        g.setBounds(0, 0, width, height)
        g.draw(c)
        dot.strokeWidth = 2.5f * d
        dot.color = ring
        c.drawCircle(gx * width, gy * height, 11f * d, dot)
    }

    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        if (width <= 0 || height <= 0) return false
        parent?.requestDisallowInterceptTouchEvent(true)
        gx = (e.x / width).coerceIn(0f, 1f)
        gy = (e.y / height).coerceIn(0f, 1f)
        invalidate()
        if (e.actionMasked == android.view.MotionEvent.ACTION_UP || e.actionMasked == android.view.MotionEvent.ACTION_CANCEL) {
            parent?.requestDisallowInterceptTouchEvent(false)
            onDone?.invoke(gx, gy)
        }
        return true
    }
}
