package com.materialyou.keyboard

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import kotlin.math.cos
import kotlin.math.sin

enum class KeyKind { LETTER, FUNCTION, SHIFT, BACKSPACE, SPACE, ENTER }

/**
 * Corner radii for keys. Returned arrays are in the format of GradientDrawable.setCornerRadii:
 * [TLx, TLy, TRx, TRy, BRx, BRy, BLx, BLy], in pixels.
 * h = height of the key face in px, d = screen density.
 */
object KeyShapes {

    fun cookieRadii(pressed: Boolean) = FloatArray(8).also { it[0] = if (pressed) 0.2f else 1f }

    fun normal(kind: KeyKind, plus: Boolean, h: Float, d: Float, square: Boolean = false): FloatArray {
        if (square) return FloatArray(8)
        val pill = h / 2f
        val small = 10f * d
        if (!plus) return all(minOf(12f * d, pill))
        return when (kind) {
            KeyKind.LETTER -> all(minOf(16f * d, pill))
            KeyKind.FUNCTION, KeyKind.SPACE -> all(pill)
            KeyKind.SHIFT -> corners(pill, pill, small, small)
            KeyKind.BACKSPACE -> corners(small, pill, pill, small)
            KeyKind.ENTER -> corners(pill, small, pill, small)
        }
    }

    fun pressed(kind: KeyKind, plus: Boolean, h: Float, d: Float, square: Boolean = false): FloatArray {
        if (square) return FloatArray(8)
        val pill = h / 2f
        val small = 10f * d
        if (!plus) return all(minOf(22f * d, pill))
        return when (kind) {
            KeyKind.LETTER -> all(pill)
            KeyKind.FUNCTION, KeyKind.SHIFT, KeyKind.BACKSPACE -> all(small)
            KeyKind.SPACE -> all(14f * d)
            KeyKind.ENTER -> corners(small, pill, small, pill)
        }
    }

    private fun all(r: Float) = FloatArray(8) { r }

    private fun corners(tl: Float, tr: Float, br: Float, bl: Float) =
        floatArrayOf(tl, tl, tr, tr, br, br, bl, bl)
}

/**
 * "Cookie" key background: an ellipse with a wavy, scalloped edge.
 * The wave amplitude is driven through setCornerRadii(radii[0] = 0..1) so the existing
 * press animation (which morphs corner radii) squishes the cookie into a smooth blob and back.
 */
class CookieDrawable(private val lobes: Int = 8, private val maxSize: Int = Int.MAX_VALUE) : GradientDrawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    var amp = 1f
        private set
    private var builtFor = -1f
    private var builtW = 0
    private var builtH = 0

    override fun setColor(argb: Int) {
        super.setColor(argb)
        paint.color = argb
        invalidateSelf()
    }

    fun setAmp(v: Float) {
        amp = v.coerceIn(0f, 1.3f)
        invalidateSelf()
    }

    override fun setCornerRadii(radii: FloatArray?) {
        amp = (radii?.getOrNull(0) ?: 1f).coerceIn(0f, 1.2f)
        invalidateSelf()
    }

    private fun build(w: Int, h: Int) {
        path.reset()
        val side = minOf(w, h, maxSize)
        val a = side / 2f
        val b = side / 2f
        val ox = (w - side) / 2f
        val oy = (h - side) / 2f
        val eps = 0.075f * amp
        val k = 1f / (1f + eps)
        val steps = 240
        for (i in 0..steps) {
            val t = (i.toDouble() / steps) * 2.0 * Math.PI
            val f = (1f + eps * cos(lobes * t).toFloat()) * k
            val x = ox + a + a * f * cos(t).toFloat()
            val y = oy + b + b * f * sin(t).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        builtFor = amp
        builtW = w
        builtH = h
    }

    override fun draw(canvas: Canvas) {
        val r = bounds
        val w = r.width()
        val h = r.height()
        if (w <= 0 || h <= 0) return
        if (builtFor != amp || builtW != w || builtH != h) build(w, h)
        val save = canvas.save()
        canvas.translate(r.left.toFloat(), r.top.toFloat())
        canvas.drawPath(path, paint)
        canvas.restoreToCount(save)
    }
}
