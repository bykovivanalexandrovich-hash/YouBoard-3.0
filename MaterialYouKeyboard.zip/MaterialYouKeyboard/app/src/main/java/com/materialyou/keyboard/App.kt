package com.materialyou.keyboard

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Bundle
import com.google.android.material.color.DynamicColors
import java.io.File

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        DynamicColors.applyToActivitiesIfAvailable(this)
        applyTheme(getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE).getString(THEME_KEY, "system") ?: "system")

        // remember the last crash so it can be shown (and copied) the next time the app opens
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                File(filesDir, CRASH_FILE).writeText(
                    "YouBoard ${BuildConfigInfo.version(this)}\nAndroid ${android.os.Build.VERSION.RELEASE} (${android.os.Build.MODEL})\n\n" +
                        android.util.Log.getStackTraceString(e)
                )
            } catch (_: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }

        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityCreated(a: Activity, b: Bundle?) {
                if (a is CrashActivity) return
                if (File(filesDir, CRASH_FILE).exists()) {
                    try {
                        a.startActivity(Intent(a, CrashActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Throwable) {
                    }
                }
            }
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityResumed(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }

    companion object {
        const val CRASH_FILE = "last_crash.txt"
        const val THEME_KEY = "app_theme"

        /** App look: "light", "dark" or "system". */
        fun applyTheme(v: String) {
            androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(
                when (v) {
                    "light" -> androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO
                    "dark" -> androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES
                    else -> androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}

object BuildConfigInfo {
    fun version(app: Application): String = try {
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "?"
    } catch (_: Throwable) {
        "?"
    }
}
