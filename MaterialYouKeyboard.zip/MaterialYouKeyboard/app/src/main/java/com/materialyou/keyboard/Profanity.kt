package com.materialyou.keyboard

/** Rough stem-based filter so that suggestions, autocorrect and swipe typing never offer swear words. */
object Profanity {
    private val rx = Regex(
        "(^|[^а-яёіїєґa-z])(" +
            "ху[йяеёию]|пизд|еб[аеёиуыл]|ёб|[сз]?уеб|бл[яє]д|бля[тд]?ь?$|сук[аиу]|мудак|мудил|пидор|пидар|педик|гандон|залуп|шлюх|дроч|" +
            "хуй|хер[ан]|жопа|говн|срать|сра[нл]|ссать|курва|курви|бляха|" +
            "fuck|shit|bitch|cunt|dick|cock|pussy|whore|slut|nigg|asshole|bastard" +
            ")"
    )

    fun bad(word: String): Boolean {
        val w = word.lowercase().replace('ё', 'е')
        if (w.length < 3) return false
        return rx.containsMatchIn(" $w") || rx.containsMatchIn(" " + word.lowercase())
    }

    fun clean(list: List<String>): List<String> = list.filter { !bad(it) }
}
