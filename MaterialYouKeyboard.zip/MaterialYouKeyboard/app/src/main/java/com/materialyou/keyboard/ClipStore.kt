package com.materialyou.keyboard

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Clipboard history kept in SharedPreferences. Pinned items stay on top and survive "clear". */
class ClipStore(private val prefs: SharedPreferences) {

    class Clip(val text: String, val pinned: Boolean, val time: Long)

    companion object {
        private const val KEY = "clips"
        private const val MAX_UNPINNED = 40
    }

    fun load(): MutableList<Clip> {
        val out = ArrayList<Clip>()
        try {
            val arr = JSONArray(prefs.getString(KEY, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Clip(o.getString("t"), o.optBoolean("p", false), o.optLong("ts", 0L)))
            }
        } catch (_: Exception) {
        }
        out.sortWith(compareByDescending<Clip> { it.pinned }.thenByDescending { it.time })
        return out
    }

    private fun save(list: List<Clip>) {
        val arr = JSONArray()
        for (c in list) {
            arr.put(JSONObject().put("t", c.text).put("p", c.pinned).put("ts", c.time))
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun add(text: String) {
        val list = load()
        val old = list.firstOrNull { it.text == text }
        list.removeAll { it.text == text }
        list.add(Clip(text, old?.pinned ?: false, System.currentTimeMillis()))
        list.sortWith(compareByDescending<Clip> { it.pinned }.thenByDescending { it.time })
        var unpinned = 0
        val trimmed = ArrayList<Clip>()
        for (c in list) {
            if (c.pinned) {
                trimmed.add(c)
            } else if (unpinned < MAX_UNPINNED) {
                trimmed.add(c)
                unpinned++
            }
        }
        save(trimmed)
    }

    fun togglePin(text: String) {
        val list = load().map { if (it.text == text) Clip(it.text, !it.pinned, it.time) else it }
        save(list)
    }

    fun remove(text: String) {
        save(load().filter { it.text != text })
    }

    fun clearUnpinned() {
        save(load().filter { it.pinned })
    }

    fun clearAll() {
        save(emptyList())
    }
}
