package com.materialyou.keyboard

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.google.android.material.appbar.MaterialToolbar

class ChangelogActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_changelog)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
            (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) !=
                    android.content.res.Configuration.UI_MODE_NIGHT_YES
        findViewById<MaterialToolbar>(R.id.cl_toolbar).setNavigationOnClickListener { finish() }

        val list = findViewById<LinearLayout>(R.id.cl_list)
        val titles = resources.getStringArray(R.array.cl_titles)
        val bodies = resources.getStringArray(R.array.cl_bodies)
        for (i in titles.indices) {
            val card = LayoutInflater.from(this).inflate(R.layout.item_log, list, false)
            card.findViewById<TextView>(R.id.log_title).text = titles[i]
            card.findViewById<TextView>(R.id.log_body).text = bodies.getOrElse(i) { "" }
            list.addView(card)
        }
        BottomBar.attach(this, BottomBar.LOG)
    }
}
