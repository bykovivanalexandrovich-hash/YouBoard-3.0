package com.materialyou.keyboard

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.google.android.material.appbar.MaterialToolbar

class ChangelogActivity : AppCompatActivity() {
    private var barCtl: BottomBar.Controller? = null

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        barCtl?.feed(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_changelog)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
            (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) !=
                    android.content.res.Configuration.UI_MODE_NIGHT_YES
        findViewById<MaterialToolbar>(R.id.cl_toolbar).setNavigationOnClickListener { finish() }

        val list = findViewById<LinearLayout>(R.id.cl_list)
        val titles = resources.getStringArray(R.array.cl_titles)
        val bodies = resources.getStringArray(R.array.cl_bodies)
        val prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        val key = "groups_open_log"
        val collapse = prefs.getBoolean("groups_collapse", true)
        val open = (if (prefs.contains(key)) prefs.getString(key, "") ?: "" else "0")
            .split(",").mapNotNull { it.toIntOrNull() }.toMutableSet()
        for (i in titles.indices) {
            val head = TextView(this).apply {
                text = titles[i]
                layoutParams = LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            Groups.style(head, true)
            val card = LayoutInflater.from(this).inflate(R.layout.item_log, list, false)
            card.findViewById<TextView>(R.id.log_title).visibility = android.view.View.GONE
            card.findViewById<TextView>(R.id.log_body).text = bodies.getOrElse(i) { "" }
            list.addView(head)
            list.addView(card)
            Groups.bind(head, card, i in open, collapse) { isOpen ->
                if (isOpen) open.add(i) else open.remove(i)
                prefs.edit().putString(key, open.joinToString(",")).apply()
            }
        }
        barCtl = BottomBar.attach(this, BottomBar.LOG)
    }
}
