package com.materialyou.keyboard

import androidx.core.graphics.ColorUtils

/** Fixed colour themes for the keyboard. "system" means the wallpaper-based Material You colours. */
object Themes {
    const val KEY = "theme"
    const val WIN95 = "win95"
    val IDS = listOf("system", "purple", "green", "blue", "orange")

    class Colors(
        val bg: Int, val letter: Int, val space: Int, val function: Int, val onFunction: Int,
        val tertiary: Int, val onTertiary: Int, val primary: Int, val onPrimary: Int,
        val pressed: Int, val onSurface: Int, val onSurfaceVariant: Int
    )

    private fun hsl(h: Float, s: Float, l: Float): Int =
        ColorUtils.HSLToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s, l))

    private fun c(v: Long): Int = v.toInt()

    fun colors(id: String, dark: Boolean): Colors? = when (id) {
        "purple" -> if (dark) Colors(
            c(0xFF211F26), c(0xFF2B2930), c(0xFF36343B), c(0xFF4A4458), c(0xFFE8DEF8),
            c(0xFF633B48), c(0xFFFFD8E4), c(0xFFD0BCFF), c(0xFF381E72), c(0xFF4F378B),
            c(0xFFE6E0E9), c(0xFFCAC4D0)
        ) else Colors(
            c(0xFFF3EDF7), c(0xFFECE6F0), c(0xFFE6E0E9), c(0xFFE8DEF8), c(0xFF1D192B),
            c(0xFFFFD8E4), c(0xFF31111D), c(0xFF6750A4), c(0xFFFFFFFF), c(0xFFEADDFF),
            c(0xFF1D1B20), c(0xFF49454F)
        )
        "win95" -> Colors(
            c(0xFFC0C0C0), c(0xFFC0C0C0), c(0xFFC0C0C0), c(0xFFC0C0C0), c(0xFF000000),
            c(0xFFC0C0C0), c(0xFF000000), c(0xFF000080), c(0xFFFFFFFF), c(0xFFB0B0B0),
            c(0xFF000000), c(0xFF000000)
        )
        "green" -> generated(138f, dark)
        "blue" -> generated(204f, dark)
        "orange" -> generated(28f, dark)
        else -> null
    }

    private fun generated(h: Float, dark: Boolean): Colors {
        val t = h + 40f
        return if (dark) Colors(
            hsl(h, 0.10f, 0.13f), hsl(h, 0.10f, 0.17f), hsl(h, 0.09f, 0.22f), hsl(h, 0.20f, 0.28f),
            hsl(h, 0.50f, 0.90f), hsl(t, 0.30f, 0.28f), hsl(t, 0.70f, 0.90f), hsl(h, 0.75f, 0.78f),
            hsl(h, 0.70f, 0.16f), hsl(h, 0.45f, 0.30f), hsl(h, 0.12f, 0.90f), hsl(h, 0.10f, 0.78f)
        ) else Colors(
            hsl(h, 0.35f, 0.95f), hsl(h, 0.30f, 0.92f), hsl(h, 0.25f, 0.89f), hsl(h, 0.55f, 0.88f),
            hsl(h, 0.45f, 0.14f), hsl(t, 0.70f, 0.90f), hsl(t, 0.60f, 0.14f), hsl(h, 0.60f, 0.36f),
            hsl(h, 0.30f, 1.00f), hsl(h, 0.80f, 0.90f), hsl(h, 0.10f, 0.12f), hsl(h, 0.10f, 0.30f)
        )
    }

    /** Colour of the round swatch in settings. */
    fun swatch(id: String): Int = colors(id, true)?.primary ?: 0
}
