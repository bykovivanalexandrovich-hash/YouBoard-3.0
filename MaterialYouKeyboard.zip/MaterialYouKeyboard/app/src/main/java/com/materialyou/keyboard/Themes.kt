package com.materialyou.keyboard

import androidx.core.graphics.ColorUtils

/** Fixed colour themes for the keyboard. "system" means the wallpaper-based Material You colours. */
object Themes {
    const val KEY = "theme"
    const val WIN95 = "win95"
    const val CUSTOM = "custom_colors"
    /** Only the system colour is built in; every other colour is added by the user ("c:RRGGBB"). */
    val IDS = listOf("system")
    private val LEGACY = listOf("purple", "green", "blue", "orange", "red")

    class Colors(
        val bg: Int, val letter: Int, val space: Int, val function: Int, val onFunction: Int,
        val tertiary: Int, val onTertiary: Int, val primary: Int, val onPrimary: Int,
        val pressed: Int, val onSurface: Int, val onSurfaceVariant: Int
    )

    private fun hsl(h: Float, s: Float, l: Float): Int =
        ColorUtils.HSLToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s, l))

    private fun c(v: Long): Int = v.toInt()

    fun colors(id: String, dark: Boolean): Colors? = when (id) {
        "purple" -> if (dark) Colors(
            c(0xFF211F26), c(0xFF2B2930), c(0xFF36343B), c(0xFF4A4458), c(0xFFE8DEF8),
            c(0xFF633B48), c(0xFFFFD8E4), c(0xFFD0BCFF), c(0xFF381E72), c(0xFF4F378B),
            c(0xFFE6E0E9), c(0xFFCAC4D0)
        ) else Colors(
            c(0xFFF3EDF7), c(0xFFECE6F0), c(0xFFE6E0E9), c(0xFFE8DEF8), c(0xFF1D192B),
            c(0xFFFFD8E4), c(0xFF31111D), c(0xFF6750A4), c(0xFFFFFFFF), c(0xFFEADDFF),
            c(0xFF1D1B20), c(0xFF49454F)
        )
        "win95" -> Colors(
            c(0xFFC0C0C0), c(0xFFC0C0C0), c(0xFFC0C0C0), c(0xFFC0C0C0), c(0xFF000000),
            c(0xFFC0C0C0), c(0xFF000000), c(0xFF000080), c(0xFFFFFFFF), c(0xFFB0B0B0),
            c(0xFF000000), c(0xFF000000)
        )
        "green" -> generated(138f, dark)
        "blue" -> generated(204f, dark)
        "orange" -> generated(28f, dark)
        "red" -> vividRed(dark)
        else -> if (id.startsWith("c:")) seed(id)?.let { fromSeed(it, dark) } else null
    }

    /** The colour a theme is built from: a user colour, an older fixed theme, or null for the system colours. */
    fun seed(id: String): Int? {
        if (id.startsWith("c:")) return id.substring(2).toLongOrNull(16)?.let { (0xFF000000 or it).toInt() }
        return if (id in LEGACY) colors(id, false)?.primary else null
    }

    fun idOf(color: Int): String = "c:%06X".format(color and 0xFFFFFF)

    fun customs(p: android.content.SharedPreferences): List<Int> =
        (p.getString(CUSTOM, "") ?: "").split(",").mapNotNull { it.trim().toLongOrNull(16)?.let { v -> (0xFF000000 or v).toInt() } }

    fun addCustom(p: android.content.SharedPreferences, color: Int) {
        val list = customs(p).filter { (it and 0xFFFFFF) != (color and 0xFFFFFF) } + color
        p.edit().putString(CUSTOM, list.joinToString(",") { "%06X".format(it and 0xFFFFFF) }).apply()
    }

    fun removeCustom(p: android.content.SharedPreferences, color: Int) {
        val list = customs(p).filter { (it and 0xFFFFFF) != (color and 0xFFFFFF) }
        p.edit().putString(CUSTOM, list.joinToString(",") { "%06X".format(it and 0xFFFFFF) }).apply()
    }

    /** Keyboard colours from one chosen colour: tones of its hue and the colour itself as the accent. */
    private fun fromSeed(seed: Int, dark: Boolean): Colors {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(seed, hsl)
        val h = hsl[0]
        val s = hsl[1].coerceIn(0.45f, 0.95f)
        val g = generated(h, dark)
        return Colors(
            g.bg, g.letter, g.space, g.function, g.onFunction, g.tertiary, g.onTertiary,
            hsl(h, s, if (dark) 0.76f else 0.38f), if (dark) hsl(h, 0.70f, 0.14f) else c(0xFFFFFFFF),
            g.pressed, g.onSurface, g.onSurfaceVariant
        )
    }

    /** A bold, saturated red: generated tones, but with a strong red accent. */
    private fun vividRed(dark: Boolean): Colors {
        val g = generated(356f, dark)
        return if (dark) Colors(
            g.bg, g.letter, g.space, g.function, g.onFunction, g.tertiary, g.onTertiary,
            c(0xFFFF3B30), c(0xFFFFFFFF), hsl(356f, 0.60f, 0.34f), g.onSurface, g.onSurfaceVariant
        ) else Colors(
            g.bg, g.letter, g.space, g.function, g.onFunction, g.tertiary, g.onTertiary,
            c(0xFFD50000), c(0xFFFFFFFF), hsl(356f, 0.85f, 0.88f), g.onSurface, g.onSurfaceVariant
        )
    }

    private fun generated(h: Float, dark: Boolean): Colors {
        val t = h + 40f
        return if (dark) Colors(
            hsl(h, 0.10f, 0.13f), hsl(h, 0.10f, 0.17f), hsl(h, 0.09f, 0.22f), hsl(h, 0.20f, 0.28f),
            hsl(h, 0.50f, 0.90f), hsl(t, 0.30f, 0.28f), hsl(t, 0.70f, 0.90f), hsl(h, 0.75f, 0.78f),
            hsl(h, 0.70f, 0.16f), hsl(h, 0.45f, 0.30f), hsl(h, 0.12f, 0.90f), hsl(h, 0.10f, 0.78f)
        ) else Colors(
            hsl(h, 0.35f, 0.95f), hsl(h, 0.30f, 0.92f), hsl(h, 0.25f, 0.89f), hsl(h, 0.55f, 0.88f),
            hsl(h, 0.45f, 0.14f), hsl(t, 0.70f, 0.90f), hsl(t, 0.60f, 0.14f), hsl(h, 0.60f, 0.36f),
            hsl(h, 0.30f, 1.00f), hsl(h, 0.80f, 0.90f), hsl(h, 0.10f, 0.12f), hsl(h, 0.10f, 0.30f)
        )
    }

    /** Colour of the round swatch in settings. */
    fun swatch(id: String): Int = seed(id) ?: colors(id, true)?.primary ?: 0
}
