import java.net.URL
import java.net.URLConnection

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.materialyou.keyboard"
    compileSdk = 35

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    defaultConfig {
        applicationId = "com.materialyou.keyboard"
        minSdk = 26
        targetSdk = 34
        versionCode = 52
        versionName = "3.7.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.autofill:autofill:1.1.0")
    implementation("com.google.android.material:material:1.12.0")
}

// Downloads word-frequency lists (RU/EN) for suggestions and autocorrect into assets.
// Source: https://github.com/hermitdave/FrequencyWords. If the download fails the build
// still succeeds, the keyboard just works without suggestions.
val fetchDicts by tasks.registering {
    doLast {
        val dir = file("src/main/assets")
        dir.mkdirs()
        val ruSingles = setOf("а", "б", "в", "ж", "и", "к", "о", "с", "у", "я")
        val enSingles = setOf("a", "i")
        val ukSingles = setOf("а", "в", "з", "і", "й", "о", "у", "я")
        val ukRegex = Regex("^[а-щьюяєіїґ']{1,24}$")
        val ruRegex = Regex("^[а-яё]{1,24}$")
        val enRegex = Regex("^[a-z]{1,24}('[a-z]{1,10})?$")
        for (l in listOf("ru", "uk", "en")) {
            val out = File(dir, "dict_$l.txt")
            if (out.exists() && out.length() > 10000) continue
            try {
                val url = URL(
                    "https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/$l/${l}_50k.txt"
                )
                val conn: URLConnection = url.openConnection()
                conn.setConnectTimeout(20000)
                conn.setReadTimeout(40000)
                val lines = conn.getInputStream().bufferedReader(Charsets.UTF_8).readLines()
                val rx = when (l) {
                    "ru" -> ruRegex
                    "uk" -> ukRegex
                    else -> enRegex
                }
                val singles = when (l) {
                    "ru" -> ruSingles
                    "uk" -> ukSingles
                    else -> enSingles
                }
                val seen = LinkedHashSet<String>()
                for (line in lines) {
                    var w = line.trim().substringBefore(' ').lowercase()
                    if (l == "ru") w = w.replace('ё', 'е')
                    if (l == "uk") w = w.replace('\u02BC', '\'').replace('\u2019', '\'')
                    if (!rx.matches(w)) continue
                    if (w.length == 1 && w !in singles) continue
                    seen.add(w)
                    if (seen.size >= 50000) break
                }
                if (seen.size > 1000) {
                    out.writeText(seen.joinToString("\n"), Charsets.UTF_8)
                    println("Dictionary $l: ${seen.size} words")
                } else {
                    println("WARNING: dictionary $l looks empty, skipped")
                }
            } catch (e: Exception) {
                println("WARNING: could not download dictionary $l: ${e.message}")
            }
        }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchDicts) }
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }.configureEach { dependsOn(fetchDicts) }
